import pygame
import math
#import random

# start pygame
pygame.init()

# constants and colors
Tile_Size = 15
path_length = 3
Width = (30*Tile_Size)
Height = (40*Tile_Size)
FPS = 30

# Colors
White = (255, 255, 255)
Black = (0, 0, 0)
Green = (0, 255, 0)
Blue = (0, 0, 255)
Red = (255, 0, 0)
Grey = (128, 128, 128)
Brown = (165, 42, 42)
Yellow = (255, 255, 0)
Tan = (210, 118, 140)
Purple = (255, 0, 255)
DGreen = (5, 255, 125)
Pink = (255, 192, 203)

# Classes
class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/WizardStill.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.health = 80
        self.max_health = 100
        self.inventory = []
        self.inventory_size = 10
        self.rect = self.image.get_rect(topleft=(x,y))
        self.speed = 5
        # Cooldown timers
        self.last_hit_time = 0
        self.last_item_use = 0


    def add_item(self, item):
        if len(self.inventory) < self.inventory_size:
            self.inventory.append(item)
        else:
            print("Inventory Full")

    def use_item(self, index):
        if 0 <= index < len(self.inventory):
            item = self.inventory[index]
            if item == "Potion" and self.health < self.max_health:
                self.health = min(self.max_health, self.health + 20)
                print("used Potion, Health:", self.health)
                del self.inventory[index]

    def update(self, walls, doors, ldoors):
        old_x, old_y = self.rect.topleft
        keys = pygame.key.get_pressed()

        if keys[pygame.K_a]:
            self.rect.x -= self.speed
        if keys[pygame.K_d]:
            self.rect.x += self.speed
        if pygame.sprite.spritecollide(self, walls, False):
            self.rect.x = old_x

        if keys[pygame.K_w]:
            self.rect.y -= self.speed
        if keys[pygame.K_s]:
            self.rect.y += self.speed

        for door in pygame.sprite.spritecollide(self, doors, False):
            if not door.open:
                self.rect.topleft = (old_x, old_y)
        for ldoor in pygame.sprite.spritecollide(self, ldoors, False):
            if not ldoor.open:
                self.rect.topleft = (old_x, old_y)
        if pygame.sprite.spritecollide(self, walls, False):
            self.rect.y = old_y

class PNPC(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size-7, Tile_Size-7])
        self.image.fill(Tan)
        self.rect = self.image.get_rect(topleft=(x-15,y-15))

class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size-7, Tile_Size-7])
        self.image.fill(Red)
        self.rect = self.image.get_rect(topleft=(x-15,y-15))
        self.health = 100
        self.max_health = 100
        self.speed = 3

    def move_to_player(self, player_rect, walls, doors, ldoors):
        old_x, old_y = self.rect.topleft
        dx = player_rect.centerx - self.rect.centerx
        dy = player_rect.centery - self.rect.centery
        distance = math.hypot(dx, dy)
        if distance > 0:
            normalized_dx = dx / distance
            normalized_dy = dy / distance

            # Move horizontally
            self.rect.x += normalized_dx * self.speed
            if pygame.sprite.spritecollide(self, walls, False):
                self.rect.x = old_x

            # Move vertically
            self.rect.y += normalized_dy * self.speed
            if pygame.sprite.spritecollide(self, walls, False):
                self.rect.y = old_y

            # Doors
            for door in pygame.sprite.spritecollide(self, doors, False):
                if not door.open:
                    self.rect.topleft = (old_x, old_y)
            for ldoor in pygame.sprite.spritecollide(self, ldoors, False):
                if not ldoor.open:
                    self.rect.topleft = (old_x, old_y)

class Sentry(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size-7, Tile_Size-7])
        self.image.fill(Red)
        self.rect = self.image.get_rect(topleft=(x-15, y-15))
class StartPoint(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Green)
        self.rect = self.image.get_rect(topleft=(x, y))

class EndPoint(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Blue)
        self.rect = self.image.get_rect(topleft=(x, y))

class Danger(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Red)
        self.rect = self.image.get_rect(topleft=(x, y))

class Teleport(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Purple)
        self.rect = self.image.get_rect(topleft=(x, y))

class Key(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Yellow)
        self.rect = self.image.get_rect(topleft=(x, y))

class Eky(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Yellow)
        self.rect = self.image.get_rect(topleft=(x, y))

class Pup(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Pink)
        self.rect = self.image.get_rect(topleft=(x, y))

class Mover(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Red)
        self.rect = self.image.get_rect(topleft=(x, y))
        self.direction = 1
        self.path_length = path_length * Tile_Size
        self.speed = 6
        self.start_x = x

    def update(self):
        self.rect.x += self.direction * self.speed
        if self.rect.x > self.start_x + self.path_length or self.rect.x < self.start_x:
            self.direction *= -1

class Door(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Brown)
        self.open = False
        self.open_color = White
        self.rect = self.image.get_rect(topleft=(x, y))
        self.update_color()

    def update_color(self):
        if self.open:
            self.image.fill(self.open_color)
        else:
            self.image.fill(Brown)

    def toggle(self):
        self.open = not self.open
        self.update_color()

class LDoor(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Brown)
        self.open = False
        self.open_color = White
        self.rect = self.image.get_rect(topleft=(x, y))
        self.update_color()

    def update_color(self):
        if self.open:
            self.image.fill(self.open_color)
        else:
            self.image.fill(Brown)

    def toggle(self):
        self.open = not self.open
        self.update_color()


class Wall(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Black)
        self.rect = self.image.get_rect(topleft=(x,y))

# (Other classes unchanged: StartPoint, EndPoint, Danger, Teleport, Key, Eky, Pup, Mover, Door, LDoor...)

# load maze
def Gamer():
    door_sprites = pygame.sprite.Group()
    ldoor_sprites = pygame.sprite.Group()
    all_sprites = pygame.sprite.Group()
    wall_sprites = pygame.sprite.Group()
    enemy_sprites = pygame.sprite.Group()
    start_point = None
    pnpc = None
    end_point = None
    sentry_sprites = pygame.sprite.Group()
    tele_sprites = pygame.sprite.Group()
    player = None
    danger_sprites = pygame.sprite.Group()
    key = None
    maze_level = []
    eky = None
    pup = None
    mover = None

    with open("Map.txt", "r") as file:
        for line in file:
            maze_level.append(line.strip())

    for row_index, row in enumerate(maze_level):
        for col_index, char in enumerate(row):
            x = col_index*Tile_Size
            y = row_index*Tile_Size

            if char == "1":
                wall = Wall(x,y)
                all_sprites.add(wall)
                wall_sprites.add(wall)
            elif char == "S":
                start_point = StartPoint(x,y)
                all_sprites.add(start_point)
                player = Player(x+Tile_Size//4,y+Tile_Size//4)
            elif char == "E":
                end_point = EndPoint(x,y)
                all_sprites.add(end_point)
            elif char == "D":
                danger = Danger(x,y)
                all_sprites.add(danger)
                danger_sprites.add(danger)
            elif char == "T":
                teleporter = Teleport(x,y)
                all_sprites.add(teleporter)
                tele_sprites.add(teleporter)
            elif char == "K":
                key = Key(x,y)
                all_sprites.add(key)
            elif char == "Y":
                eky = Eky(x,y)
                all_sprites.add(eky)
            elif char == "P":
                pup = Pup(x,y)
                all_sprites.add(pup)
            elif char == "M":
                mover = Mover(x,y)
                all_sprites.add(mover)
            elif char == "O":
                dort = Door(x,y)
                all_sprites.add(dort)
                door_sprites.add(dort)
            elif char == "L":
                ldoor = LDoor(x,y)
                all_sprites.add(ldoor)
                ldoor_sprites.add(ldoor)
            elif char == "N":
                pnpc = PNPC(x,y)
                all_sprites.add(pnpc)
            elif char == "X":
                enemy = Enemy(x,y)
                all_sprites.add(enemy)
                enemy_sprites.add(enemy)
            elif char == "I":
                sentry = Sentry(x,y)
                all_sprites.add(sentry)
                sentry_sprites.add(sentry)

    if player:
        all_sprites.add(player)

    return enemy_sprites, pnpc, ldoor_sprites, door_sprites, mover, pup, all_sprites, wall_sprites, player, start_point, end_point, danger_sprites, key, tele_sprites, eky

def player_near_door(player_rect, door_rect, pixels=5):
    proximity_zone = door_rect.inflate(pixels*2, pixels*2)
    return player_rect.colliderect(proximity_zone) 

def player_near_ldoor(player_rect, ldoor_rect, pixels=5):
    proximity_zone = ldoor_rect.inflate(pixels*2, pixels*2)
    return player_rect.colliderect(proximity_zone) 
# (Rest of the code unchanged: main game loop, event handling, rendering...)
def Main():
    screen = pygame.display.set_mode((Width, Height))
    pygame.display.set_caption("Wizard Game")
    clock = pygame.time.Clock()
    winning = 0
    dialog_active = False
    dialog_index = 0
    pdialog_line = [
        "NPC: Hello Wizard!",
        "Wizard: Meow.",
        "NPC: Here's a Health potion, be safe"
    ]

    enemy_sprites, pnpc, ldoor_sprites, door_sprites, mover, pup, all_sprites, wall_sprites, player, start_point, end_point, danger_sprites, key, tele_sprites, eky = Gamer()
    font = pygame.font.SysFont(None, 28)
    show_inventory = False
    running = True
    KeyHave = False
    last_inventory_toggle = 0  # cooldown for inventory toggle

    while running:
        pygame.display.set_caption("Health: " + str(player.health) + "/" + str(player.max_health))
        keys = pygame.key.get_pressed()

        # Enemy movement
        if enemy_sprites:
            for enemy in enemy_sprites:
                enemy.move_to_player(player.rect, wall_sprites, door_sprites, ldoor_sprites)

        if mover:
            mover.update()

        if player:
            player.update(wall_sprites, door_sprites, ldoor_sprites)

            # Win condition
            if end_point and pygame.sprite.collide_rect(player, end_point) and KeyHave: 
                print("You Win")
                running = False

            # Collisions
            elif pygame.sprite.spritecollide(player, enemy_sprites, False):
                current_time = pygame.time.get_ticks()
                if current_time - player.last_hit_time > 400:  # 400 ms cooldown
                    player.health -= 10
                    player.last_hit_time = current_time
                    print("Player hit! Health:", player.health)

            elif pygame.sprite.spritecollide(player, tele_sprites, False):
                if winning == 0:
                    player.rect.x, player.rect.y = 37, 307
                    winning += 1
                    print("Teleported")
                elif winning == 1 and KeyHave:
                    player.rect.x, player.rect.y = 307, 37
                    winning += 1
                    KeyHave = False
                    print("Teleported")

            elif key and pygame.sprite.collide_rect(player, key):
                KeyHave = True
                print("Key Collected")
                key.rect.x, key.rect.y = 1000, 1000

            elif eky and pygame.sprite.collide_rect(player, eky):
                KeyHave = True
                print("Key Collected")
                eky.rect.x, eky.rect.y = 1000, 1000

            elif pup and pygame.sprite.collide_rect(player, pup):
                player.speed = 7
                print("Power Up")
                pup.rect.x, pup.rect.y = 1000, 1000

            elif pnpc and pygame.sprite.collide_rect(player, pnpc) and not dialog_active:
                dialog_active = True
                dialog_index = 0

            if dialog_active and keys[pygame.K_SPACE]:
                dialog_index += 1
                if dialog_index >= len(pdialog_line):
                    dialog_active = False
                    player.add_item("Potion")
                    player.rect.x += 10

            if player.health == 0:
                print("Player Defeated")
                player.rect.x = 225
                player.rect.y = 500
                player.health += 50

        # Draw everything
        screen.fill(White)
        all_sprites.draw(screen)

        # Inventory overlay
        if show_inventory:
            inv_text = font.render("Inventory:", True, Grey)
            screen.blit(inv_text, (350, 10))
            for idx, item in enumerate(player.inventory):
                item_text = font.render(f"{idx+1}: {item}", True, Grey)
                screen.blit(item_text, (350, 40 + idx*30))

        # Dialog overlay
        if dialog_active and dialog_index < len(pdialog_line):
            text = font.render(pdialog_line[dialog_index], True, Grey)
            screen.blit(text, (50, 280))

        pygame.display.flip()
        clock.tick(FPS)

        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                for door in door_sprites:
                    if player_near_door(player.rect, door.rect, pixels=5):
                        door.toggle()
                for ldoor in ldoor_sprites:
                    if player_near_ldoor(player.rect, ldoor.rect, pixels=5) and KeyHave:
                        ldoor.toggle()
                    elif player_near_ldoor(player.rect, ldoor.rect, pixels=5) and not KeyHave:
                        print("Door is locked")

            if event.type == pygame.KEYDOWN and event.key == pygame.K_i:
                current_time = pygame.time.get_ticks()
                if current_time - last_inventory_toggle > 200:
                    print("Inventory toggled")
                    show_inventory = not show_inventory
                    last_inventory_toggle = current_time

        # Item use keys (1–9) with cooldown
        current_time = pygame.time.get_ticks()
        for i in range(1, 10):
            if keys[getattr(pygame, f"K_{i}")] and current_time - player.last_item_use > 200:
                player.use_item(i-1)
                player.last_item_use = current_time

    pygame.quit()



Main()
