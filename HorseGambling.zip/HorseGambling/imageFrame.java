import java.awt.*;
import java.awt.event.*;
import java.util.Scanner;
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
/**
 * adds a frame that can be set to an image
 */
public class imageFrame extends Frame {
	/**
	 * Buffered Image is the image
	 */
	private BufferedImage image;
	/**
	 * finds and sets the image
	 * @param imagePath fidns the image
	 */
		public imageFrame(String imagePath){
		try{
			image = ImageIO.read(new File(imagePath));//finds the image in the file
		}catch (IOException e){
			System.out.println("Error loading track: " + e.getMessage());// displays a message if horse isn't found
		}
	}
	/**
	 * overides the paint method to make the image
	 * @param g finds the graphics that will be used
	 */
	@Override
	public void paint(Graphics g) {
		if (image != null) {//displays image if it is given
			g.drawImage(image, 0 ,0, this);
		}
	}
}

