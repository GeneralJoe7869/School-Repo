import java.awt.*;
import java.awt.event.*;
import java.util.Scanner;
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.util.Random;
import java.io.PrintWriter;

/**
 * Contains all the objects, values, and functions of everything in the game
 */
public class Horseling{
private static int total = 0;
private static int wins = 0;
private static int counter = 0;
private static String Winner = "None";
private static String Chosen = "None";
private static int cost = 100;
private static int wager = 0;
private static boolean runs = false;
private static String filename = ("horseResults.txt");
private static imageFrame horseFrame = new imageFrame("whitebox.png");
private static imageFrame myFrame = new imageFrame("track.png"); //making the screen
//making Horses
private static Horse Glorse = new Horse ("Glorse.png"); // Glorse
private static Horse JHorse = new Horse("JohnHorse.png");// JHorse
private static Horse AHorse = new Horse("MinhorsePrime.png");//AHorse
//extra
private static Horse finland = new Horse("finland.png"); // our finnish line
private static Horse BOX = new Horse ("whitebox.png");
private static Horse expodium = new Horse("Glodium.png");
//buttons
private static Button JButton = new Button("Jorse");
private static Button AButton = new Button("Minhorse Prime");
private static Button GButton = new Button("Glorse");
private static Button myButton = new Button("Horse");
private static TextField alert = new TextField("Input wager in console", 20);
//horse ability conditions
private static boolean MA = false;
private static boolean GA = false;
/**
 * Where all of the actions take place and the game happens
 * @param args does something 
 */
	public static void main(String[] args){//sets the main screen
		Scanner kb = new Scanner(System.in);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();//set screen size
		myFrame.setSize(screenSize.width, screenSize.height);
		myFrame.setLayout(null);
		alert.setEditable(false);
		BOX.setBounds(0,0,2000,2000);
		Glorse.setBounds(50,200,100,137);
		JHorse.setBounds(50,80,110,137);
		AHorse.setBounds(50,330,110,137);
		finland.setBounds(1030, 0, 64, 558);
		alert.setBounds(50,600,200,50);
// horse buttons sizes
		JButton.setPreferredSize(new Dimension(100,50));
		JButton.setBounds(200,150, 80, 80);// locations, size
		AButton.setPreferredSize(new Dimension(100,50));
		AButton.setBounds(200,350, 80, 80);// locations, size
		GButton.setPreferredSize(new Dimension(100,50));
		GButton.setBounds(200,250, 80, 80);// locations, size
		myButton.setPreferredSize(new Dimension(100,50));
		myButton.setBounds(100,100, 80, 80);// locations, size
		myButton.setLocation(myButton.getX() + 1000, myButton.getY()+500);
		/**
		 * adds actionlistener to choose Jorse
		 */
		JButton.addActionListener(new ActionListener() {//chose Jorse
			@Override
			public void actionPerformed(ActionEvent e) {
				Chosen = "J";
				while (!runs){
					System.out.println("How much you wager, you have: " + cost + " NO DECIMALS");
					wager = kb.nextInt();
					if (wager <= cost && wager >= 1){
						runs = true;
						cost -= wager;
					}
				}
				if (runs){
					myFrame.remove(JButton);
					myFrame.remove(AButton);
					myFrame.remove(GButton);
					myFrame.remove(BOX);
					myFrame.remove(alert);
				}

			}
		});
		/**
		 * adds actionlistener to chose Minhorse Prime
		 */
		AButton.addActionListener(new ActionListener() {//chose Jorse
			@Override
			public void actionPerformed(ActionEvent e) {
				Chosen = "A";
				while (!runs){
					System.out.println("How much you wager, you have: " + cost + " NO DECIMALS");
					wager = kb.nextInt();
					if (wager <= cost && wager >= 1){
						runs = true;
						cost -= wager;
					}
				}
				if (runs){
					myFrame.remove(JButton);
					myFrame.remove(AButton);
					myFrame.remove(GButton);
					myFrame.remove(BOX);
					myFrame.remove(alert);
				}

			}
		});
		/**
		 * adds actionlistener to chose Glorse
		 */
		GButton.addActionListener(new ActionListener() {//chose Jorse
			@Override
			public void actionPerformed(ActionEvent e) {
				Chosen = "G";
				while (!runs){
					System.out.println("How much you wager, you have: " + cost + " NO DECIMALS");
					wager = kb.nextInt();
					if (wager <= cost && wager >= 1){
						runs = true;
						cost -= wager;
					}
				}
				if (runs){
					myFrame.remove(JButton);
					myFrame.remove(AButton);
					myFrame.remove(GButton);
					myFrame.remove(BOX);
					myFrame.remove(alert);
				}

			}
		});
		/**
		 * adds actionlistener to make the horses move
		 */
		myButton.addActionListener(new ActionListener() { // horse button
			@Override
			public void actionPerformed(ActionEvent e) {
				Random Randy = new Random(); // guy who appears on halloween to steal candy and worse
				//JHorse moves
				int MOVE = Randy.nextInt(17)+ 4;
				System.out.println("JHorse Position: " + JHorse.Xpos);//counts distance horse moves
				if (JHorse.Xpos > AHorse.Xpos && JHorse.Xpos > Glorse.Xpos && JHorse.Xpos >= 500)
					MOVE +=1;
				JHorse.Xpos += MOVE;//move horse (by changing its x value)
				JHorse.setLocation(JHorse.getX() + MOVE, JHorse.getY());//update screen
				//AHorse moves
				MOVE = Randy.nextInt(17)+ 4;
				System.out.println("AHorse Position: " + AHorse.Xpos);//counts distance horse moves
				if (AHorse.Xpos < JHorse.Xpos && MA == false){
					JHorse.Xpos -=20;
					JHorse.setLocation(JHorse.getX() - 20, JHorse.getY());
					MA = true;
					System.out.println("Minhorse uses their ability");
				}
				if (AHorse.Xpos < Glorse.Xpos && MA == false){
					Glorse.Xpos -=20;
					Glorse.setLocation(Glorse.getX() - 20, Glorse.getY());
					MA = true;
					System.out.println("Minhorse uses their ability");
				}
				AHorse.Xpos += MOVE;//move horse (by changing its x value)
				AHorse.setLocation(AHorse.getX() + MOVE, AHorse.getY());//update screen
				//Glorse moves
				MOVE = Randy.nextInt(17)+ 4;
				System.out.println("Glorse Position: " + Glorse.Xpos);//counts distance horse moves
				if (Glorse.Xpos < JHorse.Xpos && Glorse.Xpos < AHorse.Xpos && GA == false){
					MOVE += 30;
					GA = true;
					System.out.println("Glorse uses their ability");
				}
				Glorse.Xpos += MOVE;//move horse (by changing its x value)
				Glorse.setLocation(Glorse.getX() + MOVE, Glorse.getY());//update screen
				
				if (JHorse.Xpos >= 872){
					System.out.println("Jorse Wins");
					Winner = "J";
					myFrame.remove(myButton);
					WinScreen();}
				if (AHorse.Xpos >= 872){
					System.out.println("Minhorse Prime Wins");
					Winner = "A";
					myFrame.remove(myButton);
					WinScreen();}
				if (Glorse.Xpos >= 872){
					System.out.println("Glorse Wins");
					Winner = "G";
					myFrame.remove(myButton);
					WinScreen();}
				counter +=1; // every few clicks a horse abilities


			}
		});

//add stuff to frame
		myFrame.add(Glorse);
		myFrame.add(AHorse);//puts the jhorse on screen
		myFrame.add(JHorse);//puts the jhorse on screen
		myFrame.add(JButton);
		myFrame.add(AButton);
		myFrame.add(GButton);
		myFrame.add(alert);
		myFrame.add(BOX);
		myFrame.add(finland);
		myFrame.add(myButton);//puts a button on screen
		myFrame.setVisible(true);//shows the frame
		/**
		 * adds windowlistener to be able to close the game on screen 1 and 2
		 */
		myFrame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e){// closes the window
				System.out.println("Why'd you do that? They're glue now...");
				System.exit(0);
			}
		});
		/**
		 * adds window listener to close game on screen 3
		 */
		horseFrame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e){// closes the window
				System.out.println("Why'd you do that? They're glue now...");
				System.exit(0);
		}
	});
	}
	/**
	 * changes to the screen that shows the winner and asks if you want to go again
	 */
public static void WinScreen(){
	Button retry = new Button("Again?");
	retry.setPreferredSize(new Dimension(100,50));
	retry.setBounds(200,350, 80, 80);// locations, size
	myFrame.setVisible(false);
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	horseFrame.setSize(screenSize.width, screenSize.height);
	horseFrame.setLayout(null);
	switch (Winner){
		case "J":
			horseFrame.add(JHorse);
			JHorse.setBounds(500,500,110,137);
			break;
		case "A":
			horseFrame.add(AHorse);
			AHorse.setBounds(500,500,110,137);
			break;
		case "G":
			horseFrame.add(Glorse);
			Glorse.setBounds(500,500,110,137);
			break;
		default:
			System.out.println("This shouldnt happen");
	}
	if (Winner.equalsIgnoreCase(Chosen)){
		cost += wager*2;
		total += wager*2;
		wins += 1;
	}
	wager = 0;
	Winner = "None";
	horseFrame.add(expodium);
	try (PrintWriter printy = new PrintWriter(filename)){
		printy.println("Total Cost won: "+total);
		printy.println("Total wins: " + wins);
}
	catch(FileNotFoundException e){
		System.out.println("File not dound");
}
	horseFrame.add(retry);
	expodium.setBounds(370,435,1500,1500);
	horseFrame.setVisible(true);
	/**
	 * adds action listener to reset the game
	 */ 
	retry.addActionListener(new ActionListener() {//chose Jorse
		@Override
		public void actionPerformed(ActionEvent e) {//set screen
			myFrame.setVisible(true);
			horseFrame.setVisible(false);
			Glorse.setBounds(50,200,100,137);
			JHorse.setBounds(50,80,110,137);
			AHorse.setBounds(50,330,110,137);
			Glorse.Xpos = 0;
			JHorse.Xpos = 0;
			AHorse.Xpos = 0;
			myFrame.add(JButton);
			myFrame.add(AButton);
			myFrame.add(GButton);
			myFrame.add(AHorse);
			myFrame.add(alert);
			myFrame.add(JHorse);
			myFrame.add(Glorse);
			myFrame.add(BOX);
			myFrame.add(myButton);
			myFrame.add(finland);
			runs = false;
			MA = false;
			GA = false;
			
	}
});
}

}
