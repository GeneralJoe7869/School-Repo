import java.awt.*;
import java.awt.event.*;
import java.util.Scanner;
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
/**
 * makes a canvas with an image
 */
public class Horse extends Canvas {
	/**
	 * Buffered Image is the image 
	 */
	private BufferedImage image;
	/**
	 * Xpos tracks positions of moving horses
	 */
	int Xpos = 0;//position of image (x value)
	/**
	 * finds the image and saves it to a variable
	 * @param imagePath finds the image you want to set
	 */
		public Horse(String imagePath){
		try{
			image = ImageIO.read(new File(imagePath));//finds the image in the file
		}catch (IOException e){
			System.out.println("Error loading " + imagePath + " " + e.getMessage());// displays a message if horse isn't found
		}
	}
	/**
	 * overides the paint method to make the image
	 * @param g finds graphics that will be used
	 */
	@Override
	public void paint(Graphics g) {
		if (image != null) {//displays image if it is given
			g.drawImage(image, 0 ,0, this);
		}
	}
}
