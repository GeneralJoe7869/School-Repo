import pygame

# start pygame
pygame.init()

# constants and colors
Tile_Size = 30
path_length = 3
Width = (29*Tile_Size)
Height = (19*Tile_Size)
FPS = 30
# Colors
White = (255, 255, 255)
Black = (0, 0, 0)
Green = (0, 255, 0)
Blue = (0, 0, 255)
Red = (255, 0, 0)
Yellow = (255, 255, 0)
Purple = (255, 0, 255)
DGreen = (5, 255, 125)
Pink = (255, 192, 203)
# Classes
class Player(pygame.sprite.Sprite):
    def __init__(self, x, y): #need to fix init's to have two _ not one.
        super().__init__()
        self.image = pygame.Surface([Tile_Size/2, Tile_Size/2])
        self.image.fill(DGreen)
        self.rect = self.image.get_rect(topleft=(x,y))#you had react instead of rect.
        self.speed = 5 #moved this to init so it can be changed easier later. and used self.
        #also, you had a capital S in speed, so I changed it to lowercase s.
    def update(self, walls):
        #key presses
        old_x,old_y = self.rect.topleft
        keys = pygame.key.get_pressed()

        if keys[pygame.K_a]:
            self.rect.x -= self.speed
        if keys[pygame.K_d]:
            self.rect.x += self.speed
        if pygame.sprite.spritecollide(self, walls, False):
            self.rect.x = old_x

        if keys[pygame.K_w]:
            self.rect.y -= self.speed
        if keys[pygame.K_s]:
            self.rect.y += self.speed
        if pygame.sprite.spritecollide(self, walls, False):
            self.rect.y = old_y
    
class Wall(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Black)
        self.rect = self.image.get_rect(topleft=(x,y))
class StartPoint(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Green)
        self.rect = self.image.get_rect(topleft=(x,y))
class EndPoint(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Blue)
        self.rect = self.image.get_rect(topleft=(x,y))
class Danger(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Red)
        self.rect = self.image.get_rect(topleft=(x,y))
class Teleport(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Purple)
        self.rect = self.image.get_rect(topleft = (x,y))
class Key(pygame.sprite.Sprite):
    def __init__(self, x,y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Yellow)
        self.rect = self.image.get_rect(topleft = (x, y))
class Eky(pygame.sprite.Sprite):
    def __init__(self, x,y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Yellow)
        self.rect = self.image.get_rect(topleft = (x,y))
class Pup(pygame.sprite.Sprite):
    def __init__(self, x,y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Pink)
        self.rect = self.image.get_rect(topleft = (x,y))
class Mover(pygame.sprite.Sprite):
    def __init__(self, x,y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Red)
        self.rect = self.image.get_rect(topleft = (x,y))
        self.direction = 1
        self.path_length = path_length * Tile_Size
        self.speed = 6
        self.start_x = x
    def update(self):  #smthn abt parenthesis
        self.rect.x += self.direction * self.speed
        if self.rect.x > self.start_x + self.path_length or self.rect.x < self.start_x:
            self.direction *= -1

#load maze
def Mazer():
    all_sprites = pygame.sprite.Group()
    wall_sprites = pygame.sprite.Group()
    start_point = None
    end_point = None
    tele_sprites = pygame.sprite.Group()
    player = None
    danger_sprites = pygame.sprite.Group()
    key = None
    maze_level = []
    eky = None
    pup = None
    mover = None
    with open("Maze.txt", "r") as file:
        for line in file:
            maze_level.append(line.strip())
    print(maze_level)
    for row_index, row in enumerate(maze_level):
     for col_index, char in enumerate(row):
         x = col_index*Tile_Size
         y = row_index*Tile_Size

         if char == "1":
             wall = Wall(x,y)
             print("wall")
             all_sprites.add(wall)
             wall_sprites.add(wall)
         elif char == "S":
             start_point = StartPoint(x,y)
             all_sprites.add(start_point)
             print("start")
             #added this line to create AND draw the player at the start point
             player = Player(x+Tile_Size//4,y+Tile_Size//4)
             #player.draw_turtle()
         elif char == "E":
             end_point = EndPoint(x,y)
             all_sprites.add(end_point)
         elif char == "D":
             danger = Danger(x,y)
             all_sprites.add(danger)
             danger_sprites.add(danger)
         elif char == "T":
             teleporter = Teleport(x,y)
             all_sprites.add(teleporter)
             tele_sprites.add(teleporter)
         elif char == "K":
             key = Key(x,y)
             all_sprites.add(key)
         elif char == "Y":
             eky = Eky(x,y)
             all_sprites.add(eky)
         elif char == "P":
             pup = Pup(x,y)
             all_sprites.add(pup)
         elif char == "M":
             mover = Mover(x,y)
             all_sprites.add(mover)
             
    if player:
     all_sprites.add(player)

    return mover, pup, all_sprites, wall_sprites, player, start_point, end_point, danger_sprites, key, tele_sprites, eky

def Main():
    screen = pygame.display.set_mode((Width, Height))
    pygame.display.set_caption("Maze Game")
    clock = pygame.time.Clock()
    winning = 0
    #load maze/sprites
    mover, pup, all_sprites, wall_sprites, player, start_point, end_point, danger_sprites, key, tele_sprites, eky = Mazer()
    print("made it to load maze")
    running = True
    KeyHave = False

    while running:
        if mover:
            mover.update()
        if player:
            player.update(wall_sprites) 
            if end_point and pygame.sprite.collide_rect(player, end_point) and KeyHave: 
                print("You Win")
                running = False#added to end game on win.
            elif mover and pygame.sprite.collide_rect(player, mover):
                if winning == (2):
                    player.rect.x = 307
                    player.rect.y = 37
                    eky.rect.x = 720
                    eky.rect.y = 330
                    print("Lost Key")
            elif pygame.sprite.spritecollide(player, danger_sprites, False):
                if winning == (1):
                    player.rect.x = 37
                    player.rect.y = 307
                    KeyHave = False
                    print("Lost Key")
                    key.rect.x = 210
                    key.rect.y = 420
                if winning == (2):
                    player.rect.x = 307
                    player.rect.y = 37
                    eky.rect.x = 720
                    eky.rect.y = 330
                    print("lost Key")
            elif pygame.sprite.spritecollide(player, tele_sprites, False): #more teleporters need added
                if winning == (0):
                    player.rect.x = 37
                    player.rect.y = 307
                    winning += 1
                    print("teleported")
                elif winning == (1) and KeyHave:
                    player.rect.x = 307
                    player.rect.y = 37
                    winning += 1
                    KeyHave = False
                    print("teleported")
            elif key and pygame.sprite.collide_rect(player, key):
                KeyHave = True
                print("Key Collected")
                key.rect.x = 1000
                key.rect.y = 1000
            elif eky and pygame.sprite.collide_rect(player, eky):
                KeyHave = True
                print("Key Collected")
                eky.rect.x = 1000
                eky.rect.y = 1000
            elif pup and pygame.sprite.collide_rect(player, pup):
                player.speed = 7
                print ("power up")
                pup.rect.x = 1000
                pup.rect.y = 1000
        screen.fill(White) #you didn't have these lines to fill the screen and update display.
        all_sprites.draw(screen)
        pygame.display.flip()
        clock.tick(FPS)
        #added this to handle quitting the game.
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
    pygame.quit()


Main()

#