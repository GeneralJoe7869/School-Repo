import pygame
import math
from pygame.math import Vector2
import random
# start pygame
pygame.init()

# constants and colors
TestVar = 0
Tile_Size = 18
Level = int(0)
L1Reqs = int(0)
L2Reqs = int(0)
L3Reqs = int(0)
#map 0/start up
Width0 = (41*Tile_Size)
Height0 = (14*Tile_Size)
#map 1
Width1 = (30*Tile_Size)
Height1 = (39*Tile_Size)
startx1 = Tile_Size*16
starty1 = Tile_Size*34
#map 2
Width2 = (41*Tile_Size)
Height2 = (30*Tile_Size)
startx2 = Tile_Size*2
starty2 = Tile_Size*2
#map 3
Width3 = (30*Tile_Size)
Height3 = (49*Tile_Size)
startx3 = Tile_Size*4
starty3 = Tile_Size*43
#map 4/end
Width4 = (20*Tile_Size)
Height4 = (20*Tile_Size)
startx4 = Tile_Size*10
starty4 = Tile_Size*10
FPS = 30
width = [Width0, Width1, Width2, Width3, Width4]
height = [Height0, Height1, Height2, Height3, Height4]
current_inv = []
current_spell = "None"
deaths = 0
ldoor_opened = False
sdoor_opened = False
boss_killed = False
boss2_killed = False
finalboss_killed = False

# Colors
White = (255, 255, 255)
Black = (0, 0, 0)
Green = (34, 139, 34)
Blue = (0, 0, 255)
Red = (255, 0, 0)
Grey = (128, 128, 128)
Brown = (137, 81, 41)
Yellow = (255, 255, 0)
Tan = (210, 118, 140)
Purple = (255, 0, 255)
DGreen = (5, 255, 125)
Pink = (255, 192, 203)
Orange = (255, 165, 0)
#sounds

# FIX LEVEL 3 Boss actions

fire_cast = pygame.mixer.Sound("Sounds/FireSpell.wav")
ice_cast = pygame.mixer.Sound("Sounds/IceSpell.wav")
coin_flip = pygame.mixer.Sound("Sounds/CoinFlip.wav")
heal_noise = pygame.mixer.Sound("Sounds/Heal.wav")
death_noise = pygame.mixer.Sound("Sounds/Death.wav")
explode_noise = pygame.mixer.Sound("Sounds/Explosion.wav")
rocinante_noise = pygame.mixer.Sound("Sounds/OnwardsRocinante.wav")
# Classes
class FinalBoss(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/FinalBossStart1.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*3, Tile_Size*3))
        self.rect = self.image.get_rect(topleft=(x,y))
        self.health = 2500
        self.max_health = 2500
        self.can_shoot = False
        self.can_move = False
        self.plague_duration = 5000
        self.last_hit_time = 0
        self.last_action_time = 0
        self.starting = False
        self.live = True
        self.shoot_cooldown = 1500
        self.last_action = random.randint(0, 5)
        self.last_shot_time = 0
        self.move_anim_speed = 0.15
        self.move_anim_index = 0
        self.move_frames = [
            pygame.image.load("Sprites/FinalBossMove1.png"),
            pygame.image.load("Sprites/FinalBossMove2.png"),
        ]
        self.can_action = False
        self.current_frame = 0
        self.start_anim_frames = [ 
            pygame.image.load("Sprites/FinalBossStart1.png"),
            pygame.image.load("Sprites/FinalBossStart2.png"),
            pygame.image.load("Sprites/FinalBossStart3.png"),
            pygame.image.load("Sprites/FinalBossStart4.png"),
            pygame.image.load("Sprites/FinalBossStart5.png"),
            pygame.image.load("Sprites/FinalBossStart6.png"),
            pygame.image.load("Sprites/FinalBossStart7.png"),
            pygame.image.load("Sprites/FinalBossStart8.png"),
            pygame.image.load("Sprites/FinalBossStart9.png"),
            pygame.image.load("Sprites/FinalBossStart10.png"),
            pygame.image.load("Sprites/FinalBossStart11.png"),
            pygame.image.load("Sprites/FinalBossStart12.png"),
            pygame.image.load("Sprites/FinalBossStart13.png"),
            pygame.image.load("Sprites/FinalBossStart14.png"),
            pygame.image.load("Sprites/FinalBossStart15.png"),
            pygame.image.load("Sprites/FinalBossStart1.png"),
        ]
        self.locations = [ 
            (Tile_Size*11, Tile_Size*3),
            (Tile_Size*16, Tile_Size*3),
            (Tile_Size*11, Tile_Size*9),
            (Tile_Size*16, Tile_Size*9)]
        self.death_anim_frames = [
            pygame.image.load("Sprites/FinalBossDeath1.png"),
            pygame.image.load("Sprites/FinalBossDeath2.png"),
            pygame.image.load("Sprites/FinalBossDeath3.png"),
            pygame.image.load("Sprites/FinalBossDeath4.png"),
            pygame.image.load("Sprites/FinalBossDeath5.png"),
            pygame.image.load("Sprites/FinalBossDeath6.png"),
            pygame.image.load("Sprites/FinalBossDeath7.png"),
            pygame.image.load("Sprites/FinalBossDeath8.png"),
            pygame.image.load("Sprites/FinalBossDeath9.png"),
            pygame.image.load("Sprites/FinalBossDeath10.png"),
            pygame.image.load("Sprites/FinalBossDeath11.png"),
            pygame.image.load("Sprites/FinalBossDeath12.png"),
            pygame.image.load("Sprites/FinalBossDeath13.png"),
            pygame.image.load("Sprites/FinalBossDeath14.png"),
        ]
        self.plague = False
        self.plague_start_time = 0
        self.plague_last_hit_time = 0
    def move_to_player(self, player_rect):
        old_x, old_y = self.rect.topleft
        dx = player_rect.centerx - self.rect.centerx
        dy = player_rect.centery - self.rect.centery
        distance = math.hypot(dx, dy)
        self.speed = 3
        self.move_anim_index += self.move_anim_speed
        if self.move_anim_index >= 2:
            self.move_anim_index = 0
        frame = int(self.move_anim_index)
        self.image = self.move_frames[frame]
        self.image = pygame.transform.scale(self.image,(Tile_Size*3, Tile_Size*3))

        if self.can_move:
            if distance > 0: 
                normalized_dx = dx / distance
                normalized_dy = dy / distance

                self.rect.x += normalized_dx * self.speed
                self.rect.y += normalized_dy * self.speed


    def apply_plague(self):
        if not self.plague:
            self.plague = True
            self.plague_start_time = pygame.time.get_ticks()
            self.plague_last_hit_time = self.plague_start_time
    def shoot(self, player_rect, projectiles):
        if self.live and self.can_shoot:
            now = pygame.time.get_ticks()
            self.image = pygame.image.load("Sprites/FinalBossFrown.png")
            self.image = pygame.transform.scale(self.image,(Tile_Size*3, Tile_Size*3))
            if now - self.last_shot_time >= self.shoot_cooldown:
                projectiles.add(Projectile(self.rect.centerx, self.rect.centery, player_rect))
                self.last_shot_time = now
    def shoot_Ice(self, player_rect, evil_icicles):
        if self.live and self.can_shoot:
            now = pygame.time.get_ticks()
            self.image = pygame.image.load("Sprites/FinalBossBlue.png")
            self.image = pygame.transform.scale(self.image,(Tile_Size*3, Tile_Size*3))
            if now - self.last_shot_time >= self.shoot_cooldown:
                evil_icicle = EvilIcicle(self.rect.centerx, self.rect.centery, (self.rect.centerx, self.rect.centery), (player_rect.centerx, player_rect.centery))
                evil_icicles.add(evil_icicle)
                self.last_shot_time = now
    def shoot_plague(self, player_rect, evil_pexplosions):
        if self.live and self.can_shoot:
            now = pygame.time.get_ticks()
            self.image = pygame.image.load("Sprites/FinalBossGreen.png")
            self.image = pygame.transform.scale(self.image,(Tile_Size*3, Tile_Size*3))
            if now - self.last_shot_time >= self.shoot_cooldown:
                evil_pexplosion = EvilPlagueExplosion(player_rect.centerx, player_rect.centery)
                evil_pexplosions.add(evil_pexplosion)
                self.last_shot_time = now
    def death_anim(self):
        global finalboss_killed
        self.can_shoot = False
        self.live = False
        self.can_action = False
        animation_speed = 10
        if self.current_frame < len(self.death_anim_frames):
            self.image = self.death_anim_frames[self.current_frame]
            self.image = pygame.transform.scale(self.image,(Tile_Size*3, Tile_Size*3))
            if pygame.time.get_ticks() % animation_speed == 0: 
                 self.current_frame += 1
        else:
            print("Boss Defeated")
            global L3Reqs
            L3Reqs += 1
            self.kill()
            finalboss_killed = True
    def move(self):
        if self.live and self.can_action:
            self.location = random.randint(0, 5)
            if self.location == 0:
                self.rect.topleft = self.locations[0]
            elif self.location == 1:
                self.rect.topleft = self.locations[1]
            elif self.location == 2:
                self.rect.topleft = self.locations[2]
            elif self.location == 3:
                self.rect.topleft = self.locations[3]
            else:
                self.image = pygame.image.load("Sprites/FinalBoss.png")
                self.image = pygame.transform.scale(self.image,(Tile_Size*3, Tile_Size*3))
    def spawn_minion(self, enemy_sprites):
        if self.live:
            enemy = Enemy(self.rect.x, self.rect.y)
            enemy_sprites.add(enemy)
            self.image = pygame.image.load("Sprites/FinalBossSummon.png")
            self.image = pygame.transform.scale(self.image,(Tile_Size*3, Tile_Size*3))
    def startup(self):
        self.can_shoot = False
        self.live = False
        self.can_action = False
        animation_speed = 10
        if self.current_frame < len(self.start_anim_frames):
            self.image = self.start_anim_frames[self.current_frame]
            self.image = pygame.transform.scale(self.image,(Tile_Size*3, Tile_Size*3))
            if pygame.time.get_ticks() % animation_speed == 0: 
                 self.current_frame += 1
        else:
            self.can_action = True
            self.live = True
            self.can_shoot = True
            self.starting = False
    def update(self, player_rect, projectiles, enemy_sprites):
        self.action_cooldown = 1000
        if sdoor_opened and self.can_action:
            if pygame.time.get_ticks() - self.last_action_time >= self.action_cooldown:
                self.last_action_time = pygame.time.get_ticks()
                self.action = random.randint(0, 5)
                if self.action == 0:
                    self.move()
                    self.action = random.randint(0, 5)
                if self.action == 1:
                    self.shoot(player_rect, projectiles)
                    self.action = random.randint(0, 5)
                if self.action == 2 and self.last_action != 2:
                    self.spawn_minion(enemy_sprites)
                    self.action = random.randint(0, 5)
                if self.action == 3:
                    self.move_to_player(player_rect)
                    self.action = random.randint(0, 5)
                if self.action == 4:
                    self.shoot_Ice(player_rect, projectiles)
                    self.action = random.randint(0, 5)
                if self.action == 5:
                    self.shoot_plague(player_rect, projectiles)
                    self.action = random.randint(0, 5)
                else:
                    self.action = random.randint(0, 5)
                self.last_action = self.action
        if self.plague:
            current_time = pygame.time.get_ticks()
            if current_time - self.plague_start_time >= self.plague_duration:
                self.plague = False
            if current_time - self.plague_last_hit_time >= 500:
                self.health -= 50
                self.plague_last_hit_time = current_time
class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/WizardStill.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.health = 100
        self.can_attack = True
        self.can_cast = True
        self.plague_duration = 5000
        self.can_move = True
        self.last_heal_time = 0
        self.heal_cooldown = 1000
        self.buffed = False
        self.buff_start = 0
        self.buff_duration = 10000
        self.moving = False
        self.live = True
        self.death_anim_frames = [
            pygame.image.load("Sprites/WizardDeath1.png"),
            pygame.image.load("Sprites/WizardDeath2.png"),
            pygame.image.load("Sprites/WizardDeath3.png"),
            pygame.image.load("Sprites/WizardDeath4.png"),
            pygame.image.load("Sprites/WizardDeath5.png"),
        ]
        self.current_frame = 0
        self.walk_up_frames = [
            pygame.image.load("Sprites/WizardWalkUp1.png"),
            pygame.image.load("Sprites/WizardWalkUp2.png"),
        ]
        self.walk_down_frames = [
            pygame.image.load("Sprites/WizardWalkForward1.png"),
            pygame.image.load("Sprites/WizardWalkForward2.png"),
        ]
        self.walk_right_frames = [
            pygame.image.load("Sprites/WizardWalkRight1.png"),
            pygame.image.load("Sprites/WizardWalkRight2.png"),
        ]
        self.walk_left_frames = [
            pygame.image.load("Sprites/WizardWalkLeft1.png"),
            pygame.image.load("Sprites/WizardWalkLeft2.png"),
        ]
        self.walk_anim_index = 0
        self.walk_anim_speed = 0.15
        self.facing = "Down"
        self.max_health = 100
        self.inventory = []
        self.inventory_size = 10
        self.rect = self.image.get_rect(center=(x,y))
        self.speed = 5
        self.plague = False
        self.plague_start_time = 0
        self.plague_last_hit_time = 0
        self.Spell = "None"
        # Cooldown timers
        self.last_hit_time = 0
        self.last_item_use = 0
        self.shoot_cooldown = 1000
        self.last_shot_time = pygame.time.get_ticks()
    def add_item(self, item):
        if len(self.inventory) < self.inventory_size:
            current_inv.append(item)
        else:
            print("Spellbook Full")
    def apply_plague(self):
        if not self.plague:
            self.plague = True
            self.plague_start_time = pygame.time.get_ticks()
            self.plague_last_hit_time = self.plague_start_time
    def use_item(self, index):
        global current_spell
        if 0 <= index < len(self.inventory):
            item = self.inventory[index]
            if item == "Fireball":
                self.Spell = "Fireball"
                current_spell = "Fireball"
                print("Equipped Fireball Spell")
            if item == "Icicle":
                self.Spell = "Icicle"
                current_spell = "Icicle"
                print("Equipped Icicle Spell")
            if item == "Lag":
                self.Spell = "Lag"
                current_spell = "Lag"
                print("Equipped Lag Spell")
            if item == "Plague":
                self.Spell = "Plague"
                current_spell = "Plague"
                print("Equipped Plague Spell")
            if item == "Heal":
                self.Spell = "Heal"
                current_spell = "Heal"
                print("Equipped Heal Spell")
            if item == "Ruination":
                self.Spell = "Ruination"
                current_spell = "Ruination"
                print("Equipped Ruination Spell")
            if item == "Chance":
                self.Spell = "Chance"
                current_spell = "Chance"
                print("Equipped Chance Spell")
            if item == "Buff":
                self.Spell = "Buff"
                current_spell = "Buff"
                print("Equipped Buff Spell")

    def update(self, walls, doors, ldoors):
        old_x, old_y = self.rect.topleft
        keys = pygame.key.get_pressed()
        if self.buffed:
            if pygame.time.get_ticks() - self.buff_start >= self.buff_duration:
                self.buffed = False
                print("Buff has worn off.")
        if self.can_move:
            if keys[pygame.K_a]:
                self.rect.x -= self.speed
                self.facing = "Left"
                self.moving = True
            if keys[pygame.K_d]:
                self.rect.x += self.speed
                self.facing = "Right"
                self.moving = True
            if pygame.sprite.spritecollide(self, walls, False):
                self.rect.x = old_x

            if keys[pygame.K_w]:
                self.rect.y -= self.speed
                self.facing = "Up"
                self.moving = True
            if keys[pygame.K_s]:
                self.rect.y += self.speed
                self.facing = "Down"
                self.moving = True
            if self.moving:
                self.walk_anim_index += self.walk_anim_speed
                if self.walk_anim_index >= 2:
                    self.walk_anim_index = 0
                frame = int(self.walk_anim_index)
                if self.facing == "Up":
                    self.image = self.walk_up_frames[frame]
                    self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
                elif self.facing == "Down":
                    self.image = self.walk_down_frames[frame]
                    self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
                elif self.facing == "Right":
                    self.image = self.walk_right_frames[frame]
                    self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
                elif self.facing == "Left":
                    self.image = self.walk_left_frames[frame]
                    self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))


            for door in pygame.sprite.spritecollide(self, doors, False):
                if not door.open:
                    self.rect.topleft = (old_x, old_y)
            for ldoor in pygame.sprite.spritecollide(self, ldoors, False):
                if not ldoor.open:
                    self.rect.topleft = (old_x, old_y)
            if pygame.sprite.spritecollide(self, walls, False):
                self.rect.y = old_y 

            if not self.live:
                self.deathanim()
            if self.plague:
                current_time = pygame.time.get_ticks()
                if current_time - self.plague_start_time >= self.plague_duration:
                    self.plague = False
                if current_time - self.plague_last_hit_time >= 500:
                    self.health -= 5
                    self.plague_last_hit_time = current_time
#figure out default facing var and apply to player and enemy
            if self.facing == "Up" and not keys[pygame.K_w]:
                self.image = pygame.image.load("Sprites/WizardUp.png")
                self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
            elif self.facing == "Down" and not keys[pygame.K_s]:
                self.image = pygame.image.load("Sprites/WizardStill.png")
                self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
            elif self.facing == "Right" and not keys[pygame.K_d]:
                self.image = pygame.image.load("Sprites/WizardRight.png")
                self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
            elif self.facing == "Left" and not keys[pygame.K_a]:
                self.image = pygame.image.load("Sprites/WizardLeft.png")
                self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
    def deathanim(self):
        global deaths
        self.can_move = False
        self.can_attack = False
        self.can_cast = False
        animation_speed = 10
        if self.current_frame < len(self.death_anim_frames):
            self.image = self.death_anim_frames[self.current_frame]
            self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
            if pygame.time.get_ticks() % animation_speed == 0: 
                 self.current_frame += 1
        else:
            print("Player Defeated")
            if Level == 1:
                self.rect.x, self.rect.y = startx1, starty1
            elif Level == 2:
                self.rect.x, self.rect.y = startx2, starty2
            elif Level == 3:
                self.rect.x, self.rect.y = startx3, starty3
            self.health = self.max_health
            self.live = True
            self.current_frame = 0
            self.can_move = True
            self.can_attack = True
            self.can_cast = True
            deaths += 1
#npcs
class Goku(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Goku.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*2))
        self.rect = self.image.get_rect(topleft=(x-5,y-5))
class GNPC(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/GambleMan.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x-5,y-5))
class Villager(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/VillageMan.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x-5,y-5))
class FNPC(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/FireMan.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x-7,y-5))
class VNPC(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/PlagueMan.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x-5,y-5))
class TNPC(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/OldMan.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x-5,y-5))
class PNPC(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/MrGreen.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x-5,y-5))
class Sign(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Sign.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x,y))
class LNPC(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/LagMan.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x-5,y-5))
class INPC(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/IceMan.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x-5,y-5))

#others
class Sentry(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/SentryStill.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x-5,y-5))
        self.health = 60
        self.plague = False
        self.plague_start_time = 0
        self.plague_duration = 2500
        self.plague_last_hit_time = 0
        self.live = True
        self.can_shoot = True
        self.current_frame = 0
        self.death_anim_frames = [
            pygame.image.load("Sprites/SentryDeath1.png"),
            pygame.image.load("Sprites/SentryDeath2.png"),
            pygame.image.load("Sprites/SentryDeath3.png"),
            pygame.image.load("Sprites/SentryDeath4.png"),
            pygame.image.load("Sprites/SentryDeath5.png"),
            pygame.image.load("Sprites/SentryDeath6.png"),
        ]
        self.max_health = 60
        self.last_hit_time = 0
        self.shoot_cooldown = 1000
        self.last_shot_time = pygame.time.get_ticks()
    def update(self, player_rect, projectiles):
        if self.can_shoot and self.live:
            now = pygame.time.get_ticks()
            if now - self.last_shot_time >= self.shoot_cooldown:
                projectiles.add(Projectile(self.rect.centerx, self.rect.centery-5, player_rect))
                self.last_shot_time = now
        if self.plague:
            current_time = pygame.time.get_ticks()
            if current_time - self.plague_start_time >= self.plague_duration:
                self.plague = False
            if current_time - self.plague_last_hit_time >= 500:
                self.health -= 3
                self.plague_last_hit_time = current_time
    def apply_plague(self):
        if not self.plague:
            self.plague = True
            self.plague_start_time = pygame.time.get_ticks()
            self.plague_last_hit_time = self.plague_start_time

    def death_anim(self):
        self.can_shoot = False
        animation_speed = 5
        if self.current_frame < len(self.death_anim_frames):
            self.image = self.death_anim_frames[self.current_frame]
            self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
            if pygame.time.get_ticks() % animation_speed == 0: 
                 self.current_frame += 1
        else:
            self.live = False
            print("Sentry Defeated")
            self.health = 1
            self.can_shoot = False
class EvilIcicle(pygame.sprite.Sprite):
    def __init__(self, x, y, start_pos, target_pos):
        super().__init__()
        self.image = pygame.image.load("Sprites/Icicle.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(center=(x,y))
        self.pos = pygame.Vector2(start_pos)
        direction = pygame.Vector2(target_pos) - self.pos
        self.speed = 12
        if direction.length() != 0:
            self.direction = direction.normalize()
        else:
            self.direction = pygame.Vector2()
    def update(self, doors, ldoors, wall):
        self.pos += self.direction * self.speed
        self.rect.center = (int(self.pos.x), int(self.pos.y))
        for door in pygame.sprite.spritecollide(self, doors, False):
            if not door.open:
                self.kill()
        for ldoor in pygame.sprite.spritecollide(self, ldoors, False):
            if not ldoor.open:
                self.kill()
        for wall in pygame.sprite.spritecollide(self, wall, False):
            self.kill()
class Icicle(pygame.sprite.Sprite):
    def __init__(self, x, y, start_pos, target_pos):
        super().__init__()
        self.image = pygame.image.load("Sprites/Icicle.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(center=(x,y))
        self.pos = pygame.Vector2(start_pos)
        direction = pygame.Vector2(target_pos) - self.pos
        self.speed = 12
        if direction.length() != 0:
            self.direction = direction.normalize()
        else:
            self.direction = pygame.Vector2()
    def update(self, doors, ldoors, wall, fog):
        self.pos += self.direction * self.speed
        self.rect.center = (int(self.pos.x), int(self.pos.y))
        for door in pygame.sprite.spritecollide(self, doors, False):
            if not door.open:
                self.kill()
        for ldoor in pygame.sprite.spritecollide(self, ldoors, False):
            if not ldoor.open:
                self.kill()
        for wall in pygame.sprite.spritecollide(self, wall, False):
            self.kill()
        for fog in pygame.sprite.spritecollide(self, fog, False):
            self.kill()
class Plague(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/PoisonBomb1.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(center=(x,y))
        self.current_frame = 0
        self.death_anim_frames = [
            pygame.image.load("Sprites/PoisonBomb2.png"),
            pygame.image.load("Sprites/PoisonBomb3.png"),
            pygame.image.load("Sprites/PoisonBomb4.png"),
        ]
    def update(self):
        animation_speed = 10
        if self.current_frame < len(self.death_anim_frames):
            self.image = self.death_anim_frames[self.current_frame]
            self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
            if pygame.time.get_ticks() % animation_speed == 0: 
                 self.current_frame += 1
        else:
            TestVar == 0
class PlagueExplosion(pygame.sprite.Sprite):    
    def __init__(self, x, y): 
        super().__init__()
        self.image = pygame.image.load("Sprites/PoisonExplosion.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*4, Tile_Size*4))
        self.rect = self.image.get_rect(center=(x,y))
        self.created = pygame.time.get_ticks()
        self.timer = 200
    def update(self):
        explode_noise.play()
        current_time = pygame.time.get_ticks()
        if current_time - self.created >= self.timer:
            self.kill()
class EvilPlagueExplosion(pygame.sprite.Sprite):
    def __init__(self, x, y): 
        super().__init__()
        self.image = pygame.image.load("Sprites/PoisonExplosion.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*4, Tile_Size*4))
        self.rect = self.image.get_rect(center=(x,y))
        self.created = pygame.time.get_ticks()
        self.timer = 200
    def update(self, *args):
        explode_noise.play()
        current_time = pygame.time.get_ticks()
        if current_time - self.created >= self.timer:
            self.kill()
class HealArea(pygame.sprite.Sprite):
    def __init__(self, x, y): 
        super().__init__()
        self.image = pygame.image.load("Sprites/HealArea.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*3, Tile_Size*3))
        self.rect = self.image.get_rect(center=(x,y))
        self.created = pygame.time.get_ticks()
        self.timer = 10000  # milliseconds
        self.last_teleport = pygame.time.get_ticks()
    def update(self):
        now = pygame.time.get_ticks()
        if now - self.last_teleport >= self.timer:
            self.rect.x += 1000
            self.rect.y += 1000
            self.last_teleport = now
class Fireball(pygame.sprite.Sprite):
    def __init__(self, x, y, start_pos, target_pos):
        super().__init__()
        self.image = pygame.image.load("Sprites/FireballUp.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(center=(x,y))
        self.pos = pygame.Vector2(start_pos)
        direction = pygame.Vector2(target_pos) - self.pos
        self.speed = 10
        if direction.length() != 0:
            self.direction = direction.normalize()
        else:
            self.direction = pygame.Vector2()
    def update(self, doors, ldoors, wall, fog):
        self.pos += self.direction * self.speed
        self.rect.center = (int(self.pos.x), int(self.pos.y))
        for ldoor in pygame.sprite.spritecollide(self, ldoors, False):
            if not ldoor.open:
                print("Door blocked Fireball")
                self.kill()
        for fog in pygame.sprite.spritecollide(self, fog, False):
            self.kill()
class Explosion(pygame.sprite.Sprite):
    def __init__(self, x, y): 
        super().__init__()
        self.image = pygame.image.load("Sprites/FireballExplode.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*2, Tile_Size*2))
        self.rect = self.image.get_rect(center=(x,y))
        self.created = pygame.time.get_ticks()
        self.timer = 200  # milliseconds
    def update(self):
        current_time = pygame.time.get_ticks()
        explode_noise.play()
        if current_time - self.created >= self.timer:
            self.kill()
class Coin(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Coin1.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x,y))
        self.current_frame = 0
        self.spin_anim_frames = [
            pygame.image.load("Sprites/Coin1.png"),
            pygame.image.load("Sprites/Coin2.png"),
            pygame.image.load("Sprites/Coin3.png"),
            pygame.image.load("Sprites/Coin4.png"),
            pygame.image.load("Sprites/Coin5.png"),
            pygame.image.load("Sprites/Coin6.png"),
            pygame.image.load("Sprites/Coin1.png"),
        ]
    def update(self):
        animation_speed = 6
        if self.current_frame < len(self.spin_anim_frames):
            self.image = self.spin_anim_frames[self.current_frame]
            self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
            if pygame.time.get_ticks() % animation_speed == 0:
                 self.current_frame += 1
        else:
            self.current_frame = 0
            self.rect.x += 1000
            self.rect.y += 1000
            self.kill()
class Projectile(pygame.sprite.Sprite):
    def __init__(self, x, y, player_rect):
        super().__init__()
        self.image = pygame.image.load("Sprites/Projectile.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*.7, Tile_Size*.7))
        self.rect = self.image.get_rect(topleft=(x,y))
        self.speed = 7
        dx = player_rect[0] - x
        dy = player_rect[1] - y
        distance = math.hypot(dx, dy)
        self.vx = dx / distance * self.speed
        self.vy = dy / distance * self.speed
    def update(self, doors, ldoors, walls):
        self.rect.x += self.vx
        self.rect.y += self.vy
        for ldoor in pygame.sprite.spritecollide(self, ldoors, False):
            if not ldoor.open:
                self.kill()
        for door in pygame.sprite.spritecollide(self, doors, False):
            if not door.open:
                self.kill()
        for wall in pygame.sprite.spritecollide(self, walls, False):
            self.kill()
class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Mafia.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x,y))
        self.last_hit_time = 0
        self.plague = False
        self.plague_start_time = 0
        self.plague_duration = 2500
        self.plague_last_hit_time = 0
        self.health = 100
        self.facing = "Down"
        self.live = True
        self.can_move = True
        self.max_health = 100
        self.cold = False
        self.cold_start_time = 0
        self.cold_duration = 2500
        self.current_frame = 0
        self.move_anim_speed = 0.15
        self.cold_move_frames = [
            pygame.image.load("Sprites/MafiaColdWalk1.png"),
            pygame.image.load("Sprites/MafiaColdWalk2.png"),
        ]
        self.cold_move_anim_index = 0
        self.move_frames = [
            pygame.image.load("Sprites/MafiaWalk1.png"),
            pygame.image.load("Sprites/MafiaWalk2.png"),
        ]
        self.move_anim_index = 0
        self.death_anim_frames = [
            pygame.image.load("Sprites/MafiaDeath1.png"),
            pygame.image.load("Sprites/MafiaDeath2.png"),
            pygame.image.load("Sprites/MafiaDeath3.png"),
            pygame.image.load("Sprites/MafiaDeath4.png"),

        ]
        self.speed = 3
    def apply_plague(self):
        if not self.plague:
            self.plague = True
            self.plague_start_time = pygame.time.get_ticks()
            self.plague_last_hit_time = self.plague_start_time
    def death_anim(self):
        self.can_move = False
        self.live = False
        animation_speed = 10
        if self.current_frame < len(self.death_anim_frames):
            self.image = self.death_anim_frames[self.current_frame]
            self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
            if pygame.time.get_ticks() % animation_speed == 0: 
                 self.current_frame += 1
        else:
            print("Enemy Defeated")
            self.kill()
    def move_to_player(self, player_rect, walls, doors, ldoors, enemies):
        old_x, old_y = self.rect.topleft
        dx = player_rect.centerx - self.rect.centerx
        dy = player_rect.centery - self.rect.centery
        distance = math.hypot(dx, dy)
        if self.cold:
            self.speed = 1
            self.cold_move_anim_index += self.move_anim_speed
            if self.cold_move_anim_index >= 2:
                self.cold_move_anim_index = 0
            frame = int(self.cold_move_anim_index)
            self.image = self.cold_move_frames[frame]
            self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
            if pygame.time.get_ticks() - self.cold_start_time >= self.cold_duration:
                self.cold = False
        else:
            self.speed = 3
            self.move_anim_index += self.move_anim_speed
            if self.move_anim_index >= 2:
                self.move_anim_index = 0
            frame = int(self.move_anim_index)
            self.image = self.move_frames[frame]
            self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))

        if self.can_move:
            if distance > 0: 
                normalized_dx = dx / distance
                normalized_dy = dy / distance

                self.rect.x += normalized_dx * self.speed
                if pygame.sprite.spritecollide(self, walls, False):
                    self.rect.x = old_x

                self.rect.y += normalized_dy * self.speed

                if pygame.sprite.spritecollide(self, walls, False):
                    self.rect.y = old_y

            for door in pygame.sprite.spritecollide(self, doors, False):
                if not door.open:
                    self.rect.topleft = (old_x, old_y)
            for ldoor in pygame.sprite.spritecollide(self, ldoors, False):
                if not ldoor.open:
                    self.rect.topleft = (old_x, old_y)
            for other in enemies:
                if other is self:
                    continue
                if not other.live:
                    continue
                if self.rect.colliderect(other.rect):
        # Simple push-back to prevent overlap
                    if abs(self.rect.centerx - other.rect.centerx) > abs(self.rect.centery - other.rect.centery):
            # Push horizontally
                        if self.rect.centerx < other.rect.centerx:
                            self.rect.right = other.rect.left
                        else:
                            self.rect.left = other.rect.right
                    else:
            # Push vertically
                        if self.rect.centery < other.rect.centery:
                            self.rect.bottom = other.rect.top
                        else:
                            self.rect.top = other.rect.bottom
        if self.plague:
            current_time = pygame.time.get_ticks()
            if current_time - self.plague_start_time >= self.plague_duration:
                self.plague = False
            if current_time - self.plague_last_hit_time >= 500:
                self.health -= 5
                self.plague_last_hit_time = current_time
class Boss(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/MafiaBoss.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*2, Tile_Size*2))
        self.rect = self.image.get_rect(topleft=(x,y))
        self.last_hit_time = 0
        self.max_health = 750
        self.plague = False
        self.plague_start_time = 0
        self.plague_duration = 2500
        self.plague_last_hit_time = 0
        self.health = 750
        self.cold = False
        self.cold_start_time = 0
        self.cold_duration = 2500
        self.action = 0
        self.last_action = 0
        self.location = 0
        self.locations1 = [
            (Tile_Size*11, Tile_Size*11),
            (Tile_Size*17, Tile_Size*11),
            (Tile_Size*11, Tile_Size*17),
            (Tile_Size*17, Tile_Size*17),
        ]
        self.locations3 = [
            (Tile_Size*20, Tile_Size*22),
            (Tile_Size*20, Tile_Size*28),
            (Tile_Size*26, Tile_Size*22),
            (Tile_Size*26, Tile_Size*28),
        ]
        self.last_shot_time = 0
        self.shoot_cooldown = 1500
        self.last_action_time = 0
        self.action_cooldown = 1500
        self.can_action = True
        self.live = True
        self.can_shoot = True
        self.current_frame = 0
        self.death_anim_frames = [
            pygame.image.load("Sprites/BossDeath1.png"),
            pygame.image.load("Sprites/BossDeath2.png"),
            pygame.image.load("Sprites/BossDeath3.png"),
            pygame.image.load("Sprites/BossDeath4.png"),
            pygame.image.load("Sprites/BossDeath5.png"),
            pygame.image.load("Sprites/BossDeath6.png"),
            pygame.image.load("Sprites/BossDeath7.png"),
        ]
        self.max_health = 1000
    def apply_plague(self):
        if not self.plague:
            self.plague = True
            self.plague_start_time = pygame.time.get_ticks()
            self.plague_last_hit_time = self.plague_start_time
    def shoot(self, player_rect, projectiles):
        if self.live and self.can_shoot:
            now = pygame.time.get_ticks()
            if self.cold:
                self.image = pygame.image.load("Sprites/MafiaBossColdAttack1.png")
                self.image = pygame.transform.scale(self.image,(Tile_Size*2, Tile_Size*2))
            else:
                self.image = pygame.image.load("Sprites/MafiaBossAttack.png")
                self.image = pygame.transform.scale(self.image,(Tile_Size*2, Tile_Size*2))
            if now - self.last_shot_time >= self.shoot_cooldown:
                projectiles.add(Projectile(self.rect.centerx, self.rect.centery, player_rect))
                self.last_shot_time = now
    def death_anim(self):
        global ldoor_opened
        global boss_killed
        global boss2_killed
        self.can_shoot = False
        self.live = False
        self.can_action = False
        animation_speed = 10
        if self.current_frame < len(self.death_anim_frames):
            self.image = self.death_anim_frames[self.current_frame]
            self.image = pygame.transform.scale(self.image,(Tile_Size*2, Tile_Size*2))
            if pygame.time.get_ticks() % animation_speed == 0: 
                 self.current_frame += 1
        else:
            print("Boss Defeated")
            global L1Reqs
            L1Reqs += 1
            self.kill()
            ldoor_opened = False
            if Level == 1:
                boss_killed = True
            if Level == 3:
                boss2_killed = True
    def move(self):
        if self.live and self.can_action:
            self.location = random.randint(0, 3)
            if Level == 1:
                if self.location == 0:
                    self.rect.topleft = self.locations1[0]
                elif self.location == 1:
                    self.rect.topleft = self.locations1[1]
                elif self.location == 2:
                    self.rect.topleft = self.locations1[2]
                elif self.location == 3:
                    self.rect.topleft = self.locations1[3]
            if Level == 3:
                if self.location == 0:
                    self.rect.topleft = self.locations3[0]
                elif self.location == 1:
                    self.rect.topleft = self.locations3[1]
                elif self.location == 2:
                    self.rect.topleft = self.locations3[2]
                elif self.location == 3:
                    self.rect.topleft = self.locations3[3]
            if self.cold:
                self.image = pygame.image.load("Sprites/MafiaBossCold.png")
                self.image = pygame.transform.scale(self.image,(Tile_Size*2, Tile_Size*2))
            else:
                self.image = pygame.image.load("Sprites/MafiaBoss.png")
                self.image = pygame.transform.scale(self.image,(Tile_Size*2, Tile_Size*2))
            
    def spawn_minion(self, enemy_sprites):
        if self.live:
            enemy = Enemy(self.rect.x, self.rect.y)
            enemy_sprites.add(enemy)
            if self.cold:
                self.image = pygame.image.load("Sprites/MafiaBossColdAttack2.png")
                self.image = pygame.transform.scale(self.image,(Tile_Size*2, Tile_Size*2))
            else:
                self.image = pygame.image.load("Sprites/MafiaBossAttack2.png")
                self.image = pygame.transform.scale(self.image,(Tile_Size*2, Tile_Size*2))
    def update(self, player_rect, projectiles, enemy_sprites):
        if self.cold:
            self.action_cooldown = 2000
            if pygame.time.get_ticks() - self.cold_start_time >= self.cold_duration:
                self.cold = False
        else:
            self.action_cooldown = 1500
        if ldoor_opened and self.can_action:
            if pygame.time.get_ticks() - self.last_action_time >= self.action_cooldown:
                self.last_action_time = pygame.time.get_ticks()
                self.action = random.randint(0, 2)
                if self.action == 0:
                    self.move()
                    self.action = random.randint(0, 2)
                if self.action == 1:
                    self.shoot(player_rect, projectiles)
                    self.action = random.randint(0, 2)
                if self.action == 2 and self.last_action != 2:
                    self.spawn_minion(enemy_sprites)
                    self.action = random.randint(0, 2)
                else:
                    self.action = random.randint(0, 2)
                self.last_action = self.action
        if self.plague:
            current_time = pygame.time.get_ticks()
            if current_time - self.plague_start_time >= self.plague_duration:
                self.plague = False
            if current_time - self.plague_last_hit_time >= 500:
                self.health -= 37.5
                self.plague_last_hit_time = current_time
class StartPoint(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Spawn.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x, y))

class EndPoint(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/PortalVert.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x, y))

class Danger(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Red)
        self.rect = self.image.get_rect(topleft=(x, y))

class Teleport(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/PortalVert.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x, y))
class Teleport2(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/PortalHorz.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x, y))

class Key(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Key.gif")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x, y))
class Yek(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Key.gif")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x, y))
class Eky(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Key.gif")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x, y))

class Pup(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Rocinante.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*1.5, Tile_Size*1.5))
        self.rect = self.image.get_rect(topleft=(x, y))

class Mover(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Saw.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.can_move = True
        self.rect = self.image.get_rect(topleft=(x, y))
        self.direction = 1
        self.path_length = 7 * Tile_Size
        self.speed = 6
        self.start_x = x

    def update(self):
        if self.can_move:
            self.rect.x += self.direction * self.speed
            self.image = pygame.image.load("Sprites/Saw.png")
            self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
            if self.rect.x > self.start_x + self.path_length or self.rect.x < self.start_x:
                self.direction *= -1
        else:
            self.image = pygame.image.load("Sprites/SawCold.png")
            self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))

class Door(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Door.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.open = False
        self.open_color = White
        self.rect = self.image.get_rect(topleft=(x, y))
        self.update_color()

    def update_color(self):
        if self.open:
            self.image = pygame.image.load("Sprites/Floor.png")
            self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        else:
            self.image = pygame.image.load("Sprites/Door.png")
            self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))

    def toggle(self):
        self.open = not self.open
        self.update_color()
class GPotato(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/GoldenPotato.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x, y))
class LDoor(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Ldoor.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.open = False
        self.open_color = White
        self.rect = self.image.get_rect(topleft=(x, y))
        self.update_color()

    def update_color(self):
        if self.open:
            self.image = pygame.image.load("Sprites/Floor.png")
            self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        else:
            self.image = pygame.image.load("Sprites/Ldoor.png")
            self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))

    def toggle(self):
        self.open = not self.open
        self.update_color()
        global ldoor_opened
        ldoor_opened = True
class Pan(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Pan.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x,y))
#walls 
class Text(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([Tile_Size, Tile_Size])
        self.image.fill(Black)
        self.rect = self.image.get_rect(topleft=(x, y))
class Wall(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Wall.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x,y))
class Trees(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Trees.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x,y))
class RockWall(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/RockWall.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x,y))
class Window(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Window.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x,y))
#floors
class Credits(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Credits1.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size*20, Tile_Size*20))
        self.rect = self.image.get_rect(topleft=(x,y))
        self.current_frame = 0
        self.start = False
        self.sprites = [
            pygame.image.load("Sprites/Credits1.png"),
            pygame.image.load("Sprites/Credits2.png"),
            pygame.image.load("Sprites/Credits3.png"),
            pygame.image.load("Sprites/Credits4.png"),
            pygame.image.load("Sprites/Empty.png"),
        ]
    def update(self):
        animation_speed = 40
        if self.current_frame < len(self.sprites):
            self.image = self.sprites[self.current_frame]
            self.image = pygame.transform.scale(self.image,(Tile_Size*20, Tile_Size*20))
            if pygame.time.get_ticks() % animation_speed == 0: 
                 self.current_frame += 1
        else:
            print("You Win!")
            self.start = False
            pygame.quit()
            running = False
class Floor(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Floor.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x,y))
class Fog(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Fog.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x,y))
class PathFloor(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Path.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x,y))
class GrassFloor(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Grass.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x,y))
class Rockfloor(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/RockFloor.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x,y))
class Empty(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load("Sprites/Empty.png")
        self.image = pygame.transform.scale(self.image,(Tile_Size, Tile_Size))
        self.rect = self.image.get_rect(topleft=(x,y))
# load maze
def Gamer():
    sentry_sprites = pygame.sprite.Group()
    explosions = pygame.sprite.Group()
    pexplosions = pygame.sprite.Group()
    projectiles = pygame.sprite.Group()
    door_sprites = pygame.sprite.Group()
    ldoor_sprites = pygame.sprite.Group()
    fog_sprites = pygame.sprite.Group()
    all_sprites = pygame.sprite.Group()
    wall_sprites = pygame.sprite.Group()
    floor_sprites = pygame.sprite.Group()
    enemy_sprites = pygame.sprite.Group()
    boss_sprites = pygame.sprite.Group()
    start_point = None
    pnpc = None
    healarea = None
    potato = None
    coin_sprites = pygame.sprite.Group()
    gnpc = None
    goku = None
    pan = None
    tnpc = None
    vnpc = None
    villager = None
    sign = None
    fnpc = None
    inpc = None
    lnpc = None
    finalboss_sprites = pygame.sprite.Group()
    fireballs = pygame.sprite.Group()
    icicles = pygame.sprite.Group()
    plague_bombs = pygame.sprite.Group()
    end_point = None
    tele_sprites = pygame.sprite.Group()
    tele_sprites2 = pygame.sprite.Group()
    player = None
    danger_sprites = pygame.sprite.Group()
    key = None
    yek = None
    maze_level = []
    eky = None
    pup = None
    mover_sprites = pygame.sprite.Group()
    evil_icicles = pygame.sprite.Group()
    evil_pexplosions = pygame.sprite.Group()

    with open("Map" + str(Level) + ".txt", "r") as file:
        for line in file:
            maze_level.append(line.strip())
    
    for row_index, row in enumerate(maze_level):
        for col_index, char in enumerate(row):
            x = col_index*Tile_Size
            y = row_index*Tile_Size
            if char == "+":
                empty = Empty(x,y)
                all_sprites.add(empty)
                floor_sprites.add(empty)
            elif char == "^":
                window = Window(x,y)
                all_sprites.add(window)
                wall_sprites.add(window)
            elif char == "-":
                text = Text(x,y)
                wall_sprites.add(text)
                all_sprites.add(text)
            elif char == "*":
                trees = Trees(x,y)
                all_sprites.add(trees)
                wall_sprites.add(trees)
            elif char == "1":
                wall = Wall(x,y)
                all_sprites.add(wall)
                wall_sprites.add(wall)
            elif char == "9":
                tcredits = Credits(x,y)
                floor_sprites.add(tcredits)
            elif char == "2":
                rockwall = RockWall(x,y)
                all_sprites.add(rockwall)
                wall_sprites.add(rockwall)
            elif char == "3":
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "4":
                rockfloor = Rockfloor(x,y)
                floor_sprites.add(rockfloor)
                all_sprites.add(rockfloor)
            elif char == "5":
                grassfloor = GrassFloor(x,y)
                floor_sprites.add(grassfloor)
            elif char == "6":
                pan = Pan(x,y)
                all_sprites.add(pan)
                rockfloor = Rockfloor(x,y)
                floor_sprites.add(rockfloor)
            elif char == "7":
                villager = Villager(x,y)
                all_sprites.add(villager)
                grass = GrassFloor(x,y)
                floor_sprites.add(grass)
            elif char == "&":
                fog = Fog(x,y)
                fog_sprites.add(fog)
            elif char == "8":
                finalboss = FinalBoss(x,y)
                all_sprites.add(finalboss)
                finalboss_sprites.add(finalboss)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "S":
                start_point = StartPoint(x,y)
                all_sprites.add(start_point)
                player = Player(x+Tile_Size,y+Tile_Size)
            elif char == "@":
                path = PathFloor(x,y)
                floor_sprites.add(path)
            elif char == "E":
                end_point = EndPoint(x,y)
                all_sprites.add(end_point)
            elif char == "D":
                danger = Danger(x,y)
                all_sprites.add(danger)
                danger_sprites.add(danger)
            elif char == "T":
                teleporter = Teleport(x,y)
                all_sprites.add(teleporter)
                tele_sprites.add(teleporter)
            elif char == "H":
                potato = GPotato(x,y)
                all_sprites.add(potato)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "Q":
                teleporter2 = Teleport2(x,y)
                all_sprites.add(teleporter2)
                tele_sprites2.add(teleporter2)
            elif char == "K":
                key = Key(x,y)
                all_sprites.add(key)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "P":
                pup = Pup(x,y)
                all_sprites.add(pup)
                if Level == 3:
                    grass = GrassFloor(x,y)
                    floor_sprites.add(grass)
                else:
                    floor = Floor(x,y)
                    floor_sprites.add(floor)
            elif char == "U":
                yek = Yek(x,y)
                all_sprites.add(yek)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "V":
                vnpc = VNPC(x,y)
                all_sprites.add(vnpc)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "Z":
                tnpc = TNPC(x,y)
                all_sprites.add(tnpc)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "J":
                lnpc = LNPC(x,y)
                all_sprites.add(lnpc)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "M":
                mover = Mover(x,y)
                all_sprites.add(mover)
                mover_sprites.add(mover)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "O":
                dort = Door(x,y)
                all_sprites.add(dort)
                door_sprites.add(dort)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "L":
                ldoor = LDoor(x,y)
                all_sprites.add(ldoor)
                ldoor_sprites.add(ldoor)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "N":
                pnpc = PNPC(x,y)
                all_sprites.add(pnpc)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "X":
                enemy = Enemy(x,y)
                all_sprites.add(enemy)
                enemy_sprites.add(enemy)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "B":
                boss = Boss(x,y)
                all_sprites.add(boss)
                boss_sprites.add(boss)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "I":
                sentry = Sentry(x,y)
                all_sprites.add(sentry)
                sentry_sprites.add(sentry)
                if Level == 3 or Level == 1:
                    floor = Floor(x,y)
                    floor_sprites.add(floor)
                else:
                    rockfloor = Rockfloor(x,y)
                    floor_sprites.add(rockfloor)
            elif char == "F":
                fnpc = FNPC(x,y)
                all_sprites.add(fnpc)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "C":
                inpc = INPC(x,y)
                all_sprites.add(inpc)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "G":
                sign = Sign(x,y)
                all_sprites.add(sign)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "W":
                gnpc = GNPC(x,y)
                all_sprites.add(gnpc)
                floor = Floor(x,y)
                floor_sprites.add(floor)
            elif char == "$":
                goku = Goku(x,y)
                all_sprites.add(goku)
                floor = Floor(x,y)
                floor_sprites.add(floor)

    if player:
        all_sprites.add(player)

    return evil_icicles, evil_pexplosions, fog_sprites, pan, villager, healarea, finalboss_sprites, yek, goku, coin_sprites, gnpc, pexplosions, plague_bombs, potato, tele_sprites2, vnpc, lnpc, tnpc, boss_sprites, sign, floor_sprites, icicles, inpc, explosions, projectiles, fireballs, fnpc, sentry_sprites, enemy_sprites, pnpc, ldoor_sprites, door_sprites, mover_sprites, pup, all_sprites, wall_sprites, player, start_point, end_point, danger_sprites, key, tele_sprites, eky

def player_near_enemy(player_rect, enemy_rect, pixels=5):
    proximity_zone = enemy_rect.inflate(pixels*2, pixels*2)
    return player_rect.colliderect(proximity_zone)
def player_near_sentry(player_rect, sentry_rect, pixels=5):
    proximity_zone = sentry_rect.inflate(pixels*2, pixels*2)
    return player_rect.colliderect(proximity_zone)
def player_near_boss(player_rect, boss_rect, pixels=5):
    proximity_zone = boss_rect.inflate(pixels*2, pixels*2)
    return player_rect.colliderect(proximity_zone)
def player_near_finalboss(player_rect, finalboss_rect, pixels=5):
    proximity_zone = finalboss_rect.inflate(pixels*2, pixels*2)
    return player_rect.colliderect(proximity_zone)

def player_near_door(player_rect, door_rect, pixels=5):
    proximity_zone = door_rect.inflate(pixels*3, pixels*3)
    return player_rect.colliderect(proximity_zone) 

def player_near_ldoor(player_rect, ldoor_rect, pixels=5):
    proximity_zone = ldoor_rect.inflate(pixels*3, pixels*3)
    return player_rect.colliderect(proximity_zone) 
# (Rest of the code unchanged: main game loop, event handling, rendering...)
def Main():
    global boss2_killed
    global boss_killed
    global finalboss_killed
    global Level
    global L1Reqs
    global L2Reqs
    global L3Reqs
    global ldoor_opened
    global sdoor_opened
    screen = pygame.display.set_mode((width[Level], height[Level]))
    pygame.display.set_caption("Wizard Game")
    clock = pygame.time.Clock()
    potion_amount = 1
    area_exist = False
    potator = False
    current_time = 0
    tdialog_active = False
    frying = False
    tdialog_index = 0
    tdialog_line = [
        "Old Man: The Mafia have attacked out school!",
        "Wizard: Meow!",
        "Old Man: You need to get rid of them.",
        "Old Man: Go Learn the ice and fire spell and get rid of that boss"
    ]
    tdialog_line2 = [
        "Old Man: Good job getting rid of that boss.",
        "Wizard: Meow. :3",
        "Old Man: There are still more people that need help though.",
        "Old Man: Find them and help them out."
    ]
    pdialog_active = False
    pdialog_index = 0
    pdialog_line = [
        "Alchemist: Hello Wizard!",
        "Wizard: Meow.",
        "Alchemist: ...Here's a Health potion, be safe",
        "Alchemist: If you brig me a Golden Potato I can teach you a new spell."
    ]
    pdialog_line2 = [
        "Alchemist: You already have my spell, here's a potion though"
    ]   
    pdialog_line3 = [
        "Alchemist: You gave that potato to someone else, its fine... I guess.",
        "Alchemist: Here's a potion."
    ]
    pdialog_line4 = [
        "Alchemist: Thanks for the potato, here's the spell and a potion."
    ]
    sign_dialog_active = False
    sign_dialog_index = 0
    sign_dialog_line = [
        "Press Space to interact with NPCs and doors.",
        "Left Click to melee nearby enemies.",
        "Right Click to cast your equipped spell.",
        "Press I to open/close your Spellbook.",
        "Press H to use a health potion.",
        "Press R to check your current spell."
    ]
    ldialog_active = False
    ldialog_index = 0
    ldialog_line1 = [
        "Lag Wizard: This game runs too well...",
        "Wizard: Meow?",
        "Lag Wizard: Yeah, youre in a game.",
        "Lag Wizard: Here, take this and have some fun."
    ]
    ldialog_line2 = [
        "Lag Wizard: You already have my spell."
    ]
    vdialog_active = False
    vdialog_index = 0
    vdialog_line1 = [
        "Plague Wizard: You look like you could use a spell.",
        "Wizard: Meow.",
        "Plague Wizard: And I'd be willing to give it to you.",
        "Plague Wizard: If you could get me a Golden Potato."
    ]
    vdialog_line2 = [
        "Plague Wizard: Thanks for the tater, here's the spell."
    ]
    vdialog_line3 = [
        "Plague Wizard: You already have my spell, go bother someone else."
    ]
    vdialog_line4 = [
        "Plague Wizard: You gave the potato to that other guy, get lost!"
    ]
    gdialog_active = False
    gdialog_index = 0
    gdialog_line = [
        "Gambling Wizard: There's a 10%" + " chance ill give you a spell."
    ]
    gdialog_line2 = [
        "Gambling Wizard: You already have my spell... lucky."
    ]
    kdialog_active = False
    kdialog_index = 0
    kdialog_line = [
        "Goku: Hey, It's me Goku!",
        "Wizard: Meow?",
        "Goku: If you can beat that strong boss at the base of the tower I'll give you a spell.",
    ]
    kdialog_line2 = [
        "Goku: Nice job beating that boss, here's the spell.",
        "Goku: Anyways, I gotta go now, bye!"
    ]
    verdialog_active = False
    verdialog_index = 0
    verdialog_line = [
        "Villager: Please help, ive lost my frying pan!"
    ]
    verdialog_line2 = [
        "Villager: Thank you for finding my frying pan!"
    ]
    fdialog_active = False
    fdialog_index = 0
    fdialog_line1 = [
        "Fire Wizard: FIREBALL!",
        "Wizard: Meow?!",
        "Fire Wizard: No, but heres the spell."
    ]
    fdialog_line2 = [
        "Fire Wizard: You already have my spell, SCRAM!"
    ]
    idialog_active = False
    idialog_index = 0
    idialog_line1 = [
        "Ice Wizard: Can you tell that guy in the other room to be quiet!",
        "Wizard: Meow.",
        "Ice Wizard: If you do I'll give you a spell.",
        "Wizard: Meow!"
    ]
    idialog_line2 = [
        "Ice Wizard: Thanks for making that guy be quiet, heres the spell."
    ]
    idialog_line3 = [
        "Ice Wizard: You already have my spell, SHOO!"
        ]
    evil_icicles, evil_pexplosions,fog_sprites, pan, villager, healarea, finalboss_sprites, yek, goku, coin_sprites, gnpc, pexplosions, plague_bombs, potato, tele_sprites2, vnpc, lnpc, tnpc, boss_sprites, sign, floor_sprites, icicles, inpc, explosions, projectiles, fireballs, fnpc, sentry_sprites, enemy_sprites, pnpc, ldoor_sprites, door_sprites, mover_sprites, pup, all_sprites, wall_sprites, player, start_point, end_point, danger_sprites, key, tele_sprites, eky = Gamer()
    font = pygame.font.SysFont(None, 20)
    show_inventory = False
    running = True
    KeyHave = False
    EkyHave = False
    verq = False
    YekHave = False
    bomb_active = False
    last_inventory_toggle = 0  # cooldown for inventory toggle
    last_spell_cast = 0  # cooldown for spell casting
    while running:
        pygame.display.set_caption("Health: " + str(player.health) + "/" + str(player.max_health) + "   Potions: " + str(potion_amount) + "   Level: " + str(Level) + "   Time: " + str(pygame.time.get_ticks()//1000) + "s" + "   Deaths: " + str(deaths))
        keys = pygame.key.get_pressed()
        current_time = pygame.time.get_ticks()

        # Enemy movement
        if enemy_sprites:
            for enemy in enemy_sprites:
                if player:
                    enemy.move_to_player(player.rect, wall_sprites, door_sprites, ldoor_sprites, enemy_sprites)
        if boss_sprites:
            for boss in boss_sprites:
                boss.update(player.rect, projectiles, enemy_sprites)
        if finalboss_sprites:
            for finalboss in finalboss_sprites:
                if finalboss.starting == True:
                    finalboss.startup()
                finalboss.update(player.rect, projectiles, enemy_sprites)
        if Level == 3 and finalboss_killed == True:
            end_point = EndPoint(15*Tile_Size, 5*Tile_Size)
            all_sprites.add(end_point)
            finalboss_killed = False
        if mover_sprites:
            for mover in mover_sprites:
                mover.update()
        if Level == 2 and EkyHave == False and not eky:
            eky = Eky(3*Tile_Size, 24*Tile_Size)
            all_sprites.add(eky)
        if Level == 1 and boss_killed:
            ldoor_opened = False

        if sentry_sprites:
            for sentry in sentry_sprites:
                sentry.update(player.rect, projectiles)
                projectiles.update(door_sprites, ldoor_sprites, wall_sprites)
        if not sentry_sprites:
            for projectile in projectiles:
                projectile.kill()


        if player:
            player.update(wall_sprites, door_sprites, ldoor_sprites)
            player.inventory = current_inv
            if pdialog_active or fdialog_active or idialog_active or sign_dialog_active or tdialog_active or ldialog_active or vdialog_active or gdialog_active or kdialog_active or verdialog_active:
                player.can_move = False
                player.can_attack = False
                player.can_cast = False
                for enemy in enemy_sprites:
                    enemy.can_move = False
                for projectile in projectiles:
                    projectile.kill()
                for sentry in sentry_sprites:
                    sentry.can_shoot = False
            else:
                player.can_move = True
                player.can_attack = True
                player.can_cast = True
                for enemy in enemy_sprites:
                    enemy.can_move = True
                for sentry in sentry_sprites:
                    sentry.can_shoot = True
            if Level == 0:
                player.can_move = False
                start_point.image = pygame.image.load("Sprites/Empty.png")
                now = pygame.time.get_ticks()
                then = (1500)
                if now - then >= then:
                    Level += 1
                    evil_icicles, evil_pexplosions,fog_sprites, pan, villager, healarea, finalboss_sprites, yek, goku, coin_sprites, gnpc, pexplosions, plague_bombs, potato, tele_sprites2, vnpc, lnpc, tnpc, boss_sprites, sign, floor_sprites, icicles, inpc, explosions, projectiles, fireballs, fnpc, sentry_sprites, enemy_sprites, pnpc, ldoor_sprites, door_sprites, mover_sprites, pup, all_sprites, wall_sprites, player, start_point, end_point, danger_sprites, key, tele_sprites, eky = Gamer()
                    screen = pygame.display.set_mode((width[Level], height[Level]))
                    player.can_move = True
            if Level == 2:
                ldoor_opened = False
                if "Heal" in player.inventory or "Plague" in player.inventory or potator == True:
                    potato.rect.x += 1000
                    potato.rect.y += 1000
            if Level == 4:
                player.can_move = False
                player.image = pygame.image.load("Sprites/WizardVictory.png")
                player.image = pygame.transform.scale(player.image,(Tile_Size*1.5, Tile_Size*1.5))
                start_point.image = pygame.image.load("Sprites/Empty.png")
                for tcredits in floor_sprites:
                    tcredits.start = True
                    tcredits.update()
            

            if potion_amount > 10:
                potion_amount = 10
                print("Max Potions Reached")
            if healarea:
                healarea.update()
            for coin in coin_sprites:
                coin.update()
            for explosion in explosions:
                explosion.update()
            for fireball in fireballs:
                fireball.update(door_sprites, ldoor_sprites, wall_sprites, fog_sprites)

# Fireball collisions

                if pygame.sprite.groupcollide(finalboss_sprites, fireballs, False, False):
                    collisions = pygame.sprite.groupcollide(finalboss_sprites, fireballs, False, False)
                    for finalboss in collisions:
                        current_time = pygame.time.get_ticks()
                        if current_time - finalboss.last_hit_time > 500 and finalboss.live:
                            if player.buffed:
                                finalboss.health -= 15
                            else:
                                finalboss.health -= 10
                            explosion = (Explosion(fireball.rect.centerx, fireball.rect.centery))
                            explosions.add(explosion)
                            all_sprites.add(explosion)
                            fireball.kill()
                if pygame.sprite.groupcollide(enemy_sprites, fireballs, False, False):
                    collisions = pygame.sprite.groupcollide(enemy_sprites, fireballs, False, False)
                    for enemy in collisions:
                        current_time = pygame.time.get_ticks()
                        if current_time - enemy.last_hit_time > 500 and enemy.live: 
                            if enemy.cold and not player.buffed:
                                enemy.health -= 15
                            if player.buffed and not enemy.cold:
                                enemy.health -= 15
                            if enemy.cold and player.buffed:
                                enemy.health -= 20
                            else:
                                enemy.health -= 10
                            explosion = (Explosion(fireball.rect.centerx, fireball.rect.centery))
                            explosions.add(explosion)
                            fireball.kill()
                if pygame.sprite.groupcollide(sentry_sprites, fireballs, False, False):
                    collisions = pygame.sprite.groupcollide(sentry_sprites, fireballs, False, False)
                    for sentry in collisions:
                        if sentry.live:
                            current_time = pygame.time.get_ticks()
                            if current_time - sentry.last_hit_time > 500 and sentry.live:
                                if player.buffed:
                                    sentry.health -= 15
                                else:
                                    sentry.health -= 10
                                explosion = (Explosion(fireball.rect.centerx, fireball.rect.centery))
                                explosions.add(explosion)
                                fireball.kill()
                if pygame.sprite.groupcollide(wall_sprites, fireballs, False, False):
                    explosion = (Explosion(fireball.rect.centerx, fireball.rect.centery))
                    explosions.add(explosion)
                    fireball.kill()
                if pygame.sprite.groupcollide(door_sprites, fireballs, False, False):
                    collisions = pygame.sprite.groupcollide(door_sprites, fireballs, False, False)
                    for door in collisions:
                        if not door.open:
                            door.kill()
                if pygame.sprite.spritecollide(sign, fireballs, False):
                    sign.kill()
                    sign.rect.x += 1000
                    sign.rect.y += 1000
                if pygame.sprite.groupcollide(boss_sprites, fireballs, False, False):
                    collisions = pygame.sprite.groupcollide(boss_sprites, fireballs, False, False)
                    for boss in collisions:
                        current_time = pygame.time.get_ticks()
                        if current_time - boss.last_hit_time > 500 and boss.live:
                            if boss.cold and not player.buffed:
                                boss.health -= 15
                            elif player.buffed and not boss.cold:
                                boss.health -= 15
                            elif boss.cold and player.buffed:
                                boss.health -= 20
                            else:
                                boss.health -= 10
                        explosion = (Explosion(fireball.rect.centerx, fireball.rect.centery))
                        explosions.add(explosion)
                        all_sprites.add(explosion)
                        fireball.kill()
                if pygame.sprite.groupcollide(mover_sprites, fireballs, False, False):
                    collisions = pygame.sprite.groupcollide(mover_sprites, fireballs, False, False)
                    for mover in collisions:
                        mover.can_move = True
                    explosion = (Explosion(fireball.rect.centerx, fireball.rect.centery))
                    explosions.add(explosion)
                    all_sprites.add(explosion)
                    fireball.kill()
#Explosion Collisions
                if pygame.sprite.groupcollide(finalboss_sprites, explosions, False, False):
                    collisions = pygame.sprite.groupcollide(finalboss_sprites, explosions, False, False)
                    for finalboss in collisions:
                        current_time = pygame.time.get_ticks()
                        if current_time - finalboss.last_hit_time > 500 and finalboss.live:
                            if player.buffed:
                                finalboss.health -= 45
                            else:  
                                finalboss.health -= 30
                        finalboss.last_hit_time = current_time
                if pygame.sprite.groupcollide(enemy_sprites, explosions, False, False):
                    collisions = pygame.sprite.groupcollide(enemy_sprites, explosions, False, False)
                    for enemy in collisions:
                        current_time = pygame.time.get_ticks()
                        if current_time - enemy.last_hit_time > 500 and enemy.live:
                            if enemy.cold and not player.buffed:
                                enemy.health -= 45
                                enemy.cold = False
                            elif player.buffed and not enemy.cold:
                                enemy.health -= 45
                            elif enemy.cold and player.buffed:
                                enemy.health -= 60
                                enemy.cold = False
                            else:
                                enemy.health -= 30
                            enemy.last_hit_time = current_time
                if pygame.sprite.groupcollide(sentry_sprites, explosions, False, False):
                    collisions = pygame.sprite.groupcollide(sentry_sprites, explosions, False, False)
                    for sentry in collisions:
                        current_time = pygame.time.get_ticks()
                        if current_time - sentry.last_hit_time > 500 and sentry.live:
                            sentry.health -= 30
                            sentry.last_hit_time = current_time
                if pygame.sprite.groupcollide(door_sprites, explosions, False, False):
                    collisions = pygame.sprite.groupcollide(door_sprites, explosions, False, False)
                    for door in collisions:
                        if not door.open:
                            door.kill()
                if pygame.sprite.spritecollide(sign, explosions, False):
                    sign.kill()
                    sign.rect.x += 1000
                    sign.rect.y += 1000
                if pygame.sprite.groupcollide(boss_sprites, explosions, False, False):
                    collisions = pygame.sprite.groupcollide(boss_sprites, explosions, False, False)
                    for boss in collisions:
                        current_time = pygame.time.get_ticks()
                        if current_time - boss.last_hit_time > 500 and boss.live:
                            if boss.cold and not player.buffed:
                                boss.health -= 45
                                boss.cold = False
                                if boss.action == 0:
                                    boss.image = pygame.image.load("Sprites/MafiaBoss.png")
                                    boss.image = pygame.transform.scale(boss.image,(Tile_Size*2, Tile_Size*2))
                                elif boss.action == 1:
                                    boss.image = pygame.image.load("Sprites/MafiaBossAttack.png")
                                    boss.image = pygame.transform.scale(boss.image,(Tile_Size*2, Tile_Size*2))
                                elif boss.action == 2:
                                    boss.image = pygame.image.load("Sprites/MafiaBossAttack2.png")
                                    boss.image = pygame.transform.scale(boss.image,(Tile_Size*2, Tile_Size*2))
                            elif player.buffed and not boss.cold:
                                boss.health -= 45
                            elif boss.cold and player.buffed:
                                boss.health -= 60
                                boss.cold = False
                                if boss.action == 0:
                                    boss.image = pygame.image.load("Sprites/MafiaBoss.png")
                                    boss.image = pygame.transform.scale(boss.image,(Tile_Size*2, Tile_Size*2))
                                elif boss.action == 1:
                                    boss.image = pygame.image.load("Sprites/MafiaBossAttack.png")
                                    boss.image = pygame.transform.scale(boss.image,(Tile_Size*2, Tile_Size*2))
                                elif boss.action == 2:
                                    boss.image = pygame.image.load("Sprites/MafiaBossAttack2.png")
                                    boss.image = pygame.transform.scale(boss.image,(Tile_Size*2, Tile_Size*2))
                            else:
                                boss.health -= 30
                        boss.last_hit_time = current_time
                if pygame.sprite.groupcollide(mover_sprites, explosions, False, False):
                    collisions = pygame.sprite.groupcollide(mover_sprites, explosions, False, False)
                    for mover in collisions:
                        mover.can_move = True
#Plague Explosions Collisions
            for plague_bomb in plague_bombs:
                plague_bomb.update()
            for pexplosion in pexplosions:
                pexplosions.update()
                if pygame.sprite.groupcollide(enemy_sprites, pexplosions, False, False):
                    collisions = pygame.sprite.groupcollide(enemy_sprites, pexplosions, False, False)
                    for enemy in collisions:
                        enemy.apply_plague()
                if pygame.sprite.groupcollide(sentry_sprites, pexplosions, False, False):
                    collisions = pygame.sprite.groupcollide(sentry_sprites, pexplosions, False, False)
                    for sentry in collisions:
                        sentry.apply_plague()
                if pygame.sprite.groupcollide(boss_sprites, pexplosions, False, False):
                    collisions = pygame.sprite.groupcollide(boss_sprites, pexplosions, False, False)
                    for boss in collisions:
                        boss.apply_plague()
                if pygame.sprite.groupcollide(finalboss_sprites, pexplosions, False, False):
                    collisions = pygame.sprite.groupcollide(finalboss_sprites, pexplosions, False, False)
                    for finalboss in collisions:
                        finalboss.apply_plague()
#Icicle collisions
            for icicle in icicles:
                icicle.update(door_sprites, ldoor_sprites, wall_sprites, fog_sprites)

                if pygame.sprite.groupcollide(finalboss_sprites, icicles, False, False):
                    collisions = pygame.sprite.groupcollide(finalboss_sprites, icicles, False, False)
                    for finalboss in collisions:
                        current_time = pygame.time.get_ticks()
                        if current_time - finalboss.last_hit_time > 500 and finalboss.live:
                            if player.buffed:
                                finalboss.health -= 25
                            else:
                                finalboss.health -= 20
                            finalboss.last_hit_time = current_time
                if pygame.sprite.groupcollide(enemy_sprites, icicles, False, False):
                    collisions = pygame.sprite.groupcollide(enemy_sprites, icicles, False, False)
                    for enemy in collisions:
                        current_time = pygame.time.get_ticks()
                        if current_time - enemy.last_hit_time > 500 and enemy.live: 
                            if enemy.cold and not player.buffed:
                                enemy.health -= 25
                            elif player.buffed and not enemy.cold:
                                enemy.health -= 25
                            elif enemy.cold and player.buffed:
                                enemy.health -= 30
                            else:
                                enemy.health -= 20
                            enemy.cold = True
                            enemy.cold_start_time = current_time
                            enemy.last_hit_time = current_time
                if pygame.sprite.groupcollide(sentry_sprites, icicles, False, False):
                    collisions = pygame.sprite.groupcollide(sentry_sprites, icicles, False, False)
                    for sentry in collisions:
                        current_time = pygame.time.get_ticks()
                        if current_time - sentry.last_hit_time > 500 and sentry.live: 
                            if player.buffed:
                                sentry.health -= 30
                            else:
                                sentry.health -= 25
                            sentry.last_hit_time = current_time
                if pygame.sprite.groupcollide(boss_sprites, icicles, False, False):
                    collisions = pygame.sprite.groupcollide(boss_sprites, icicles, False, False)
                    for boss in collisions:
                        current_time = pygame.time.get_ticks()
                        if current_time - boss.last_hit_time > 500 and boss.live: 
                            if boss.cold and not player.buffed:
                                boss.health -= 25
                            elif player.buffed and not boss.cold:
                                boss.health -= 25
                            elif boss.cold and player.buffed:
                                boss.health -= 30
                            else:
                                boss.health -= 20
                            boss.cold = True
                            boss.cold_start_time = current_time
                            if boss.action == 0:
                                boss.image = pygame.image.load("Sprites/MafiaBossCold.png")
                                boss.image = pygame.transform.scale(boss.image,(Tile_Size*2, Tile_Size*2))
                            elif boss.action == 1:
                                boss.image = pygame.image.load("Sprites/MafiaBossColdAttack1.png")
                                boss.image = pygame.transform.scale(boss.image,(Tile_Size*2, Tile_Size*2))
                            elif boss.action == 2:
                                boss.image = pygame.image.load("Sprites/MafiaBossColdAttack2.png")
                                boss.image = pygame.transform.scale(boss.image,(Tile_Size*2, Tile_Size*2))
                        boss.last_hit_time = current_time
                if pygame.sprite.groupcollide(mover_sprites, icicles, False, False):
                    collisions = pygame.sprite.groupcollide(mover_sprites, icicles, False, False)
                    for mover in collisions:
                        mover.can_move = False
#evil icicle collisions
            for evil_icicle in evil_icicles:
                evil_icicle.update(door_sprites, ldoor_sprites, wall_sprites)
                if pygame.sprite.spritecollide(player, evil_icicle, False, False):
                    if player.live:
                        current_time = pygame.time.get_ticks()
                        if current_time - player.last_hit_time > 500: 
                            player.health -= 20
                            player.last_hit_time = current_time
                            if player.health < 0:
                                player.health = 0
                            print("Player hit! Health:", player.health)
# evil pexplosion collisions
            for evil_pexplosion in evil_pexplosions:
                evil_pexplosion.update()
                if pygame.sprite.spritecollide(player, evil_pexplosion, False, False):
                    if player.live:
                        player.apply_plague()
# Collisions
            if pygame.sprite.spritecollide(player, finalboss_sprites, False):
                if finalboss.live and player.live:
                    current_time = pygame.time.get_ticks()
                    if current_time - player.last_hit_time > 500: 
                        player.health -= 15
                        player.last_hit_time = current_time
                        if player.health < 0:
                            player.health = 0
                        print("Player hit! Health:", player.health)
            elif pygame.sprite.spritecollide(player, fog_sprites, False):
                if not sdoor_opened:
                    sdoor_opened = True
                    finalboss.starting = True
                    print("Final Boss Started")
                else:
                    player.rect.y -= 35
            elif pygame.sprite.spritecollide(player, enemy_sprites, False):
                if enemy.live and player.live:
                    current_time = pygame.time.get_ticks()
                    if current_time - player.last_hit_time > 500: 
                        player.health -= 5
                        player.last_hit_time = current_time
                        if player.health < 0:
                            player.health = 0
                        print("Player hit! Health:", player.health)
            elif pygame.sprite.spritecollide(player, boss_sprites, False):
                if boss.live and player.live:
                    current_time = pygame.time.get_ticks()
                    if current_time - player.last_hit_time > 500: 
                        player.health -= 10
                        player.last_hit_time = current_time
                        if player.health < 0:
                            player.health = 0
                        print("Player hit! Health:", player.health)

            elif pygame.sprite.spritecollide(player, mover_sprites, False):
                if player.live:
                    current_time = pygame.time.get_ticks()
                    if current_time - player.last_hit_time > 500: 
                        player.health -= 30
                        player.last_hit_time = current_time
                        if player.health < 0:
                            player.health = 0
                        print("Player hit! Health:", player.health)

            elif pygame.sprite.spritecollide(player, tele_sprites, False):
                if L1Reqs < 3 and Level == 1:
                    print("There's still more to learn here...")
                    player.rect.y -= 35
                elif L1Reqs >= 3 and Level == 1:
                    Level += 1
                    print("Leaving to Village")
                    if EkyHave == False:
                        KeyHave = False
                    if EkyHave:
                        KeyHave = True
                    if YekHave == False:
                        YekHave = False
                    if YekHave:
                        KeyHave = True
                    ldoor_opened = False
                    evil_icicles, evil_pexplosions, fog_sprites, pan, villager, healarea, finalboss_sprites, yek, goku, coin_sprites, gnpc, pexplosions, plague_bombs, potato, tele_sprites2, vnpc, lnpc, tnpc, boss_sprites, sign, floor_sprites, icicles, inpc, explosions, projectiles, fireballs, fnpc, sentry_sprites, enemy_sprites, pnpc, ldoor_sprites, door_sprites, mover_sprites, pup, all_sprites, wall_sprites, player, start_point, end_point, danger_sprites, key, tele_sprites, eky = Gamer()
                    screen = pygame.display.set_mode((width[Level], height[Level]))
                    player.inventory = current_inv
                    player.Spell = current_spell
                elif L1Reqs >= 3 and Level == 2:
                    Level -= 1
                    print("Leaving to Wizard Academy")
                    KeyHave = True
                    evil_icicles, evil_pexplosions, fog_sprites, pan, villager, healarea, finalboss_sprites, yek, goku, coin_sprites, gnpc, pexplosions, plague_bombs, potato, tele_sprites2, vnpc, lnpc, tnpc, boss_sprites, sign, floor_sprites, icicles, inpc, explosions, projectiles, fireballs, fnpc, sentry_sprites, enemy_sprites, pnpc, ldoor_sprites, door_sprites, mover_sprites, pup, all_sprites, wall_sprites, player, start_point, end_point, danger_sprites, key, tele_sprites, eky = Gamer()
                    screen = pygame.display.set_mode((width[Level], height[Level]))
                    player.inventory = current_inv
                    player.Spell = current_spell
            elif pygame.sprite.spritecollide(player, tele_sprites2, False):
                if L2Reqs < 3 and Level == 2:
                    print("You should help more people...")
                    player.rect.x -= 35
                elif L2Reqs >= 3 and Level == 2:
                    Level += 1
                    if YekHave == False:
                        KeyHave = False
                    if YekHave:
                        KeyHave = True
                    print("Leaving to Mafia Tower")
                    evil_icicles, evil_pexplosions, fog_sprites, pan, villager, healarea, finalboss_sprites, yek, goku, coin_sprites, gnpc, pexplosions, plague_bombs, potato, tele_sprites2, vnpc, lnpc, tnpc, boss_sprites, sign, floor_sprites, icicles, inpc, explosions, projectiles, fireballs, fnpc, sentry_sprites, enemy_sprites, pnpc, ldoor_sprites, door_sprites, mover_sprites, pup, all_sprites, wall_sprites, player, start_point, end_point, danger_sprites, key, tele_sprites, eky = Gamer()
                    screen = pygame.display.set_mode((width[Level], height[Level]))
                    player.inventory = current_inv
                    player.Spell = current_spell
                elif L2Reqs >= 3 and Level == 3:
                    Level -= 1
                    KeyHave = True
                    print("Leaving to Village")
                    evil_icicles, evil_pexplosions, fog_sprites, pan, villager, healarea, finalboss_sprites, yek, goku, coin_sprites, gnpc, pexplosions, plague_bombs, potato, tele_sprites2, vnpc, lnpc, tnpc, boss_sprites, sign, floor_sprites, icicles, inpc, explosions, projectiles, fireballs, fnpc, sentry_sprites, enemy_sprites, pnpc, ldoor_sprites, door_sprites, mover_sprites, pup, all_sprites, wall_sprites, player, start_point, end_point, danger_sprites, key, tele_sprites, eky = Gamer()
                    screen = pygame.display.set_mode((width[Level], height[Level]))
                    player.inventory = current_inv
                    player.Spell = current_spell
            elif end_point and pygame.sprite.collide_rect(player, end_point):
                Level += 1
                evil_icicles, evil_pexplosions, fog_sprites, pan, villager, healarea, finalboss_sprites, yek, goku, coin_sprites, gnpc, pexplosions, plague_bombs, potato, tele_sprites2, vnpc, lnpc, tnpc, boss_sprites, sign, floor_sprites, icicles, inpc, explosions, projectiles, fireballs, fnpc, sentry_sprites, enemy_sprites, pnpc, ldoor_sprites, door_sprites, mover_sprites, pup, all_sprites, wall_sprites, player, start_point, end_point, danger_sprites, key, tele_sprites, eky = Gamer()
                screen = pygame.display.set_mode((width[Level], height[Level]))
                player.inventory = current_inv
                player.Spell = current_spell
            elif key and pygame.sprite.collide_rect(player, key):
                key.kill()
                key.rect.x += 1000
                key.rect.y += 1000
                KeyHave = True
                print("Key Collected")
            elif pan and pygame.sprite.collide_rect(player, pan):
                pan.kill()
                pan.rect.x += 1000
                pan.rect.y += 1000
                print("Frying Pan Collected")
                frying = True
            elif healarea and pygame.sprite.collide_rect(player, healarea):
                if pygame.time.get_ticks() - player.last_heal_time >= 1000:
                    player.health += 10
                    player.last_heal_time = pygame.time.get_ticks()
                    print("Healed 10 Health")
                    if player.health > player.max_health:
                        player.health = player.max_health
            elif yek and pygame.sprite.collide_rect(player, yek):
                yek.kill()
                yek.rect.x += 1000
                yek.rect.y += 1000
                YekHave = True
                KeyHave = True
                print("Key Collected")

            elif eky and pygame.sprite.collide_rect(player, eky):
                eky.kill()
                eky.rect.x += 1000
                eky.rect.y += 1000
                EkyHave = True
                KeyHave = True
                print("Key Collected")
            elif potato and pygame.sprite.collide_rect(player, potato):
                potato.kill()
                potato.rect.x += 1000
                potato.rect.y += 1000
                potator = True
            elif pup and pygame.sprite.collide_rect(player, pup):
                player.speed = 7
                print("Power Up")
                rocinante_noise.play()
                pup.rect.x, pup.rect.y = 1000, 1000
            elif pnpc and pygame.sprite.collide_rect(player, pnpc) and not pdialog_active:
                pdialog_active = True
                pdialog_index = 0
            elif tnpc and pygame.sprite.collide_rect(player, tnpc) and not tdialog_active:
                tdialog_active = True
                tdialog_index = 0
            elif pnpc and pygame.sprite.collide_rect(player, fnpc) and not fdialog_active:
                fdialog_active = True
                fdialog_index = 0
            elif villager and pygame.sprite.collide_rect(player, villager) and not verdialog_active:
                verdialog_active = True
                verdialog_index = 0
            elif goku and pygame.sprite.collide_rect(player, goku) and not kdialog_active:
                kdialog_active = True
                kdialog_index = 0
            elif gnpc and pygame.sprite.collide_rect(player, gnpc) and not gdialog_active:
                gdialog_active = True
                gdialog_index = 0
            elif vnpc and pygame.sprite.collide_rect(player, vnpc) and not vdialog_active:
                vdialog_active = True
                vdialog_index = 0
            elif lnpc and pygame.sprite.collide_rect(player, lnpc) and not ldialog_active:
                ldialog_active = True
                ldialog_index = 0
            elif sign and pygame.sprite.collide_rect(player, sign) and not sign_dialog_active:
                sign_dialog_active = True
                sign_dialog_index = 0
            elif inpc and pygame.sprite.collide_rect(player, inpc) and not idialog_active:
                idialog_active = True
                idialog_index = 0
            elif pygame.sprite.spritecollide(player, projectiles, False):
                if player.live:
                    current_time = pygame.time.get_ticks()
                    if current_time - player.last_hit_time > 500:  # 400 ms cooldown
                        player.health -= 15
                        player.last_hit_time = current_time
                        if player.health < 0:
                            player.health = 0
                        print("Player hit! Health:", player.health)
                    for projectile in pygame.sprite.spritecollide(player, projectiles, True):
                        projectile.kill()


            if pdialog_active and keys[pygame.K_SPACE]:
                pdialog_index += 1
                pygame.time.delay(100)
                if potator == False and "Plague" not in player.inventory and "Heal" not in player.inventory:
                    if pdialog_index >= len(pdialog_line):
                        pdialog_active = False
                        potion_amount += 1
                        if pnpc and pygame.sprite.collide_rect(player, pnpc):
                            player.rect.x += 35
                if potator == True and "Plague" not in player.inventory and "Heal" not in player.inventory:
                    if pdialog_index >= len(pdialog_line4):
                        pdialog_active = False
                        potion_amount += 1
                        potator = False
                        player.add_item("Heal")
                        L2Reqs += 1
                        if pnpc and pygame.sprite.collide_rect(player, pnpc):
                            player.rect.x += 35
                if potator == False and "Plague" in player.inventory and "Heal" not in player.inventory:
                    if pdialog_index >= len(pdialog_line3):
                        pdialog_active = False
                        potion_amount += 1
                        if pnpc and pygame.sprite.collide_rect(player, pnpc):
                            player.rect.x += 35
                if "Heal" in player.inventory and potator == False and "Plague" not in player.inventory:
                    if pdialog_index >= len(pdialog_line2):
                        pdialog_active = False
                        potion_amount += 1
                        if pnpc and pygame.sprite.collide_rect(player, pnpc):
                            player.rect.x += 35
            if tdialog_active and keys[pygame.K_SPACE]:
                tdialog_index += 1
                pygame.time.delay(100)
                if tdialog_index >= len(tdialog_line):
                    tdialog_active = False
                    if tnpc and pygame.sprite.collide_rect(player, tnpc):
                        player.rect.x -= 35
            if sign_dialog_active and keys[pygame.K_SPACE]:
                sign_dialog_index += 1
                pygame.time.delay(100)
                if sign_dialog_index >= len(sign_dialog_line):
                    sign_dialog_active = False
                    if sign and pygame.sprite.collide_rect(player, sign):
                        player.rect.x += 35
            if ldialog_active and keys[pygame.K_SPACE]:
                ldialog_index += 1
                pygame.time.delay(100)
                if "Lag" not in player.inventory:
                    if ldialog_index >= len(ldialog_line1):
                        ldialog_active = False
                        player.add_item("Lag")
                        if lnpc and pygame.sprite.collide_rect(player, lnpc):
                            player.rect.x += 35
                if "Lag" in player.inventory:
                    if ldialog_index >= len(ldialog_line2):
                        ldialog_active = False
                        if lnpc and pygame.sprite.collide_rect(player, lnpc):
                            player.rect.x += 35
            if vdialog_active and keys[pygame.K_SPACE]:
                vdialog_index += 1
                pygame.time.delay(100)
                if "Plague" not in player.inventory and potator == False and "Heal" not in player.inventory:
                    if vdialog_index >= len(vdialog_line1):
                        vdialog_active = False
                        if vnpc and pygame.sprite.collide_rect(player, vnpc):
                            player.rect.x -= 35
                if "Heal" not in player.inventory and potator == True and "Plague" not in player.inventory:
                    if vdialog_index >= len(vdialog_line2):
                        vdialog_active = False
                        player.add_item("Plague")
                        potator = False
                        L2Reqs += 1
                        if vnpc and pygame.sprite.collide_rect(player, vnpc):
                            player.rect.x -= 35
                if "Plague" in player.inventory and potator == False and "Heal" not in player.inventory:
                    if vdialog_index >= len(vdialog_line3):
                        vdialog_active = False
                        if vnpc and pygame.sprite.collide_rect(player, vnpc):
                            player.rect.x -= 35
                if "Heal" in player.inventory and potator == False and "Plague" not in player.inventory:
                    if vdialog_index >= len(vdialog_line4):
                        vdialog_active = False
                        if vnpc and pygame.sprite.collide_rect(player, vnpc):
                            player.rect.x -= 35
            if gdialog_active and keys[pygame.K_SPACE]:
                gdialog_index += 1
                pygame.time.delay(100)
                if "Chance" not in player.inventory:
                    if gdialog_index >= len(gdialog_line):
                        gdialog_active = False
                        if random.randint(1,10) == 1:
                            player.add_item("Chance")
                            L2Reqs += 1
                        if gnpc and pygame.sprite.collide_rect(player, gnpc):
                            player.rect.x -= 35
                if "Chance" in player.inventory:
                    if gdialog_index >= len(gdialog_line2):
                        gdialog_active = False
                        if gnpc and pygame.sprite.collide_rect(player, gnpc):
                            player.rect.x -= 35
            if kdialog_active and keys[pygame.K_SPACE]:
                kdialog_index += 1
                pygame.time.delay(100)
                if not boss2_killed:
                    if kdialog_index >= len(kdialog_line):
                        kdialog_active = False
                        if goku and pygame.sprite.collide_rect(player, goku):
                            player.rect.x += 35
                if boss2_killed:
                    if kdialog_index >= len(kdialog_line2):
                        kdialog_active = False
                        if goku and pygame.sprite.collide_rect(player, goku):
                            player.rect.x += 35
                        goku.rect.x += 1000
                        goku.rect.y += 1000
                        player.add_item("Buff")
                        goku.kill()
            if verdialog_active and keys[pygame.K_SPACE]:
                verdialog_index += 1
                pygame.time.delay(100)
                if not frying:
                    if verdialog_index >= len(verdialog_line):
                        verdialog_active = False
                        if villager and pygame.sprite.collide_rect(player, villager):
                            player.rect.x -= 35
                if frying and not verq:
                    if verdialog_index >= len(verdialog_line2):
                        verdialog_active = False
                        L2Reqs += 1
                        verq = True
                        if villager and pygame.sprite.collide_rect(player, villager):
                            player.rect.x -= 35
                if verq:
                    if verdialog_index >= len(verdialog_line2):
                        verdialog_active = False
                        if villager and pygame.sprite.collide_rect(player, villager):
                            player.rect.x -= 35
            if fdialog_active and keys[pygame.K_SPACE]:
                fdialog_index += 1
                pygame.time.delay(100)
                if "Fireball" not in player.inventory:
                    if fdialog_index >= len(fdialog_line1):
                        fdialog_active = False
                        player.add_item("Fireball")
                        L1Reqs += 1
                        if fnpc and pygame.sprite.collide_rect(player, fnpc):
                            player.rect.x -= 35
                if "Fireball" in player.inventory:
                    if fdialog_index >= len(fdialog_line2):
                        fdialog_active = False
                        if fnpc and pygame.sprite.collide_rect(player, fnpc):
                            player.rect.x -= 35
            if idialog_active and keys[pygame.K_SPACE]:
                idialog_index += 1
                pygame.time.delay(100)
                if "fireball" not in player.inventory:
                    if idialog_index >= len(idialog_line1):
                        idialog_active = False
                        if inpc and pygame.sprite.collide_rect(player, inpc):
                            player.rect.x += 35
                if "Fireball" in player.inventory and "Icicle" not in player.inventory:
                    if idialog_index >= len(idialog_line2):
                        idialog_active = False
                        if "Icicle" not in player.inventory and "Fireball" in player.inventory:
                            player.add_item("Icicle")
                            L1Reqs += 1
                        if inpc and pygame.sprite.collide_rect(player, inpc):
                            player.rect.x += 35
                if "Icicle" in player.inventory:
                    if idialog_index >= len(idialog_line3):
                        idialog_active = False
                        if inpc and pygame.sprite.collide_rect(player, inpc):
                            player.rect.x += 35

            if player.health <= 0:
                player.live = False
                player.deathanim()
                death_noise.play()
            
            for enemy in enemy_sprites:
                if enemy.health < 0:
                    enemy.live = False
                    enemy.death_anim()
            for sentry in sentry_sprites:
                if sentry.health <= 0 and sentry.live:
                    sentry.can_shoot = False
                    sentry.death_anim()
            for boss in boss_sprites:
                if boss.health <= 0:
                    boss.live = False
                    boss.can_action = False
                    boss.death_anim()
            for finalboss in finalboss_sprites:
                if finalboss.health <= 0:
                    finalboss.live = False
                    finalboss.can_action = False
                    finalboss.death_anim()

# Inventory overlay
        if show_inventory:
            inv_text = font.render("Spellbook:", True, Brown)
            screen.blit(inv_text, (Tile_Size*1, 10))
            for idx, item in enumerate(player.inventory):
                if item == "Fireball":
                    item_text = font.render(f"{idx+1}: {item}", True, Red)
                    screen.blit(item_text, (Tile_Size*1 , 40 + idx*30))
                elif item == "Icicle":
                    item_text = font.render(f"{idx+1}: {item}", True, Blue)
                    screen.blit(item_text, (Tile_Size*1 , 40 + idx*30))
                elif item == "Lag":
                    item_text = font.render(f"{idx+1}: {item}", True, Purple)
                    screen.blit(item_text, (Tile_Size*1 , 40 + idx*30))
                elif item == "Plague":
                    item_text = font.render(f"{idx+1}: {item}", True, Green)
                    screen.blit(item_text, (Tile_Size*1 , 40 + idx*30))
                elif item == "Chance":
                    item_text = font.render(f"{idx+1}: {item}", True, Yellow)
                    screen.blit(item_text, (Tile_Size*1 , 40 + idx*30))
                elif item == "Heal":
                    item_text = font.render(f"{idx+1}: {item}", True, DGreen)
                    screen.blit(item_text, (Tile_Size*1 , 40 + idx*30))
                elif item == "Buff":
                    item_text = font.render(f"{idx+1}: {item}", True, Orange)
                    screen.blit(item_text, (Tile_Size*1 , 40 + idx*30))

# pdialog
        if pdialog_line and pdialog_active and pdialog_index < len(pdialog_line) and "Plague" not in player.inventory and potator == False and "Heal" not in player.inventory:
            text = font.render(pdialog_line[pdialog_index], True, DGreen)
            screen.blit(text, (50, 280))
        if pdialog_line2 and pdialog_active and pdialog_index < len(pdialog_line2) and "Heal" in player.inventory and potator == False and "Plague" not in player.inventory:
            text = font.render(pdialog_line2[pdialog_index], True, DGreen)
            screen.blit(text, (50, 280))
        if pdialog_line3 and pdialog_active and pdialog_index < len(pdialog_line3) and potator == False and "Plague" in player.inventory and "Heal" not in player.inventory:
            text = font.render(pdialog_line3[pdialog_index], True, DGreen)
            screen.blit(text, (50, 280))
        if pdialog_line4 and pdialog_active and pdialog_index < len(pdialog_line4) and potator == True and "Plague" not in player.inventory and "Heal" not in player.inventory:
            text = font.render(pdialog_line4[pdialog_index], True, DGreen)
            screen.blit(text, (50, 280))
# tdialog
        if tdialog_active and tdialog_index < len(tdialog_line) and L1Reqs < 3:
            text = font.render(tdialog_line[tdialog_index], True, White)
            screen.blit(text, (50, 280))
        if tdialog_active and tdialog_index < len(tdialog_line2) and L1Reqs >= 3:
            text = font.render(tdialog_line2[tdialog_index], True, White)
            screen.blit(text, (50, 280))
# ldialog
        if ldialog_active and ldialog_index < len(ldialog_line1) and "Lag" not in player.inventory:
            text = font.render(ldialog_line1[ldialog_index], True, Purple)
            screen.blit(text, (50, 280))
        if ldialog_active and ldialog_index < len(ldialog_line2) and "Lag" in player.inventory:
            text = font.render(ldialog_line2[ldialog_index], True, Purple)
            screen.blit(text, (50, 280))
# vdialog
        if vdialog_active and vdialog_index < len(vdialog_line1) and "Plague" not in player.inventory and potator == False and "Heal" not in player.inventory:
            text = font.render(vdialog_line1[vdialog_index], True, DGreen)
            screen.blit(text, (50, 280))
        if vdialog_active and vdialog_index < len(vdialog_line2) and "Plague" not in player.inventory and potator == True and "Heal" not in player.inventory:
            text = font.render(vdialog_line2[vdialog_index], True, DGreen)
            screen.blit(text, (50, 280))
        if vdialog_active and vdialog_index < len(vdialog_line3) and "Plague" in player.inventory and potator == False and "Heal" not in player.inventory:
            text = font.render(vdialog_line3[vdialog_index], True, DGreen)
            screen.blit(text, (50, 280))
        if vdialog_active and vdialog_index < len(vdialog_line4) and "Plague" not in player.inventory and potator == False and "Heal" in player.inventory:
            text = font.render(vdialog_line4[vdialog_index], True, DGreen)
            screen.blit(text, (50, 280))
# gdialog
        if gdialog_active and gdialog_index < len(gdialog_line) and "Chance" not in player.inventory:
            text = font.render(gdialog_line[gdialog_index], True, Yellow)
            screen.blit(text, (50, 280))
        if gdialog_active and gdialog_index < len(gdialog_line2) and "Chance" in player.inventory:
            text = font.render(gdialog_line2[gdialog_index], True, Yellow)
            screen.blit(text, (50, 280))
# kdialog
        if kdialog_active and kdialog_index < len(kdialog_line) and not boss2_killed:
            text = font.render(kdialog_line[kdialog_index], True, Orange)
            screen.blit(text, (50, 280))
        if kdialog_active and kdialog_index < len(kdialog_line2) and boss2_killed:
            text = font.render(kdialog_line2[kdialog_index], True, Orange)
            screen.blit(text, (50, 280))
# verdialog
        if verdialog_active and verdialog_index < len(verdialog_line) and not frying:
            text = font.render(verdialog_line[verdialog_index], True, Brown)
            screen.blit(text, (50, 280))
        if verdialog_active and verdialog_index < len(verdialog_line2) and frying:
            text = font.render(verdialog_line2[verdialog_index], True, Brown)
            screen.blit(text, (50, 280))
# fdialog
        if fdialog_active and fdialog_index < len(fdialog_line1) and "Fireball" not in player.inventory:
            text = font.render(fdialog_line1[fdialog_index], True, Red)
            screen.blit(text, (50, 280))
        if fdialog_active and fdialog_index < len(fdialog_line1) and "Fireball" in player.inventory:
            text = font.render(fdialog_line2[fdialog_index], True, Red)
            screen.blit(text, (50, 280))    
# idialog
        if idialog_active and idialog_index < len(idialog_line1) and "Fireball" not in player.inventory:
            text = font.render(idialog_line1[idialog_index], True, Blue)
            screen.blit(text, (50, 280))
        if idialog_active and idialog_index < len(idialog_line2) and "Fireball" in player.inventory and "Icicle" not in player.inventory:
            text = font.render(idialog_line2[idialog_index], True, Blue)
            screen.blit(text, (50, 280))
        if idialog_active and idialog_index < len(idialog_line3) and "Icicle" in player.inventory:
            text = font.render(idialog_line3[idialog_index], True, Blue)
            screen.blit(text, (50, 280))
# sign dialog
        if sign_dialog_active and sign_dialog_index < len(sign_dialog_line):
            text = font.render(sign_dialog_line[sign_dialog_index], True, Brown)
            screen.blit(text, (50, 280))
        pygame.display.flip()
        clock.tick(FPS)

# Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                for door in door_sprites:
                    if player_near_door(player.rect, door.rect, pixels=5):
                        door.toggle()
                for ldoor in ldoor_sprites:
                    if player_near_ldoor(player.rect, ldoor.rect, pixels=5) and KeyHave:
                        ldoor.toggle()
                    elif player_near_ldoor(player.rect, ldoor.rect, pixels=5) and not KeyHave:
                        print("Door is locked")
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1 and player.can_attack == True:
                    #play atack anim
                    for enemy in enemy_sprites:
                        if player_near_enemy(player.rect, enemy.rect, pixels=5):
                            if enemy.cold and not player.buffed:
                                enemy.health -= 25
                            elif player.buffed and not enemy.cold:
                                enemy.health -= 25
                            elif enemy.cold and player.buffed:
                                enemy.health -= 30
                            else:
                                enemy.health -= 20
                    for sentry in sentry_sprites:
                        if player_near_sentry(player.rect, sentry.rect, pixels=5):
                            if player.buffed:
                                sentry.health -= 30
                            else:
                                sentry.health -= 20
                    for boss in boss_sprites:
                        if player_near_boss(player.rect, boss.rect, pixels=5):
                            if boss.cold and not player.buffed:
                                boss.health -= 25
                            elif player.buffed and not boss.cold:
                                boss.health -= 25
                            elif boss.cold and player.buffed:
                                boss.health -= 30
                            else:
                                boss.health -= 20
                    for finalboss in finalboss_sprites:
                        if player_near_finalboss(player.rect, finalboss.rect, pixels=5):
                            if player.buffed:
                                finalboss.health -= 30
                            else:
                                finalboss.health -= 20
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 3 and player.can_cast == True:
                    current_time = pygame.time.get_ticks()
                    if current_time - last_spell_cast > 500:
                    #play spell anim
                        last_spell_cast = current_time + 1
                        if player.Spell == "None":
                            for enemy in enemy_sprites:
                                if player_near_enemy(player.rect, enemy.rect, pixels=5):
                                    if enemy.cold:
                                        enemy.health -= 25
                                    else:
                                        enemy.health -= 20
                                if player_near_sentry(player.rect, sentry.rect, pixels=5):
                                    sentry.health -= 20
                        if player.Spell == "Fireball":
                            mouse_pos = pygame.mouse.get_pos()
                            fireball = (Fireball(player.rect.centerx, player.rect.centery, (player.rect.centerx, player.rect.centery), mouse_pos))
                            fireballs.add(fireball)
                            fire_cast.play()
                        if player.Spell == "Icicle":
                            mouse_pos = pygame.mouse.get_pos()
                            icicle = (Icicle(player.rect.centerx, player.rect.centery, (player.rect.centerx, player.rect.centery), mouse_pos))
                            icicles.add(icicle)
                            ice_cast.play()
                        if player.Spell == "Lag":
                            pygame.time.wait(500)
                        if player.Spell == "Plague" and bomb_active == False:
                            plague = Plague(player.rect.centerx, player.rect.centery)
                            plague_bombs.add(plague)
                            all_sprites.add(plague)
                            bomb_active = True
                        elif player.Spell == "Plague" and bomb_active == True:
                            bomb_active = False
                            for plague in plague_bombs:
                                plague.update()
                                pexplosion = PlagueExplosion(plague.rect.centerx, plague.rect.centery)
                                pexplosions.add(pexplosion)
                                all_sprites.add(pexplosion)
                                plague.kill()
                        if player.Spell == "Heal":
                            if not area_exist:
                                healarea = HealArea(player.rect.centerx, player.rect.centery)
                                all_sprites.add(healarea)
                                area_exist = True
                            if area_exist:
                                healarea.rect.centerx = player.rect.centerx
                                healarea.rect.centery = player.rect.centery
                                healarea.start_time = pygame.time.get_ticks()
                                healarea.last_teleport = pygame.time.get_ticks()
                        if player.Spell == "Ruination":
                            for enemy in enemy_sprites:
                                enemy.health = -1
                            for sentry in sentry_sprites:
                                sentry.health = -1
                            for boss in boss_sprites:
                                boss.health = -1
                            for finalboss in finalboss_sprites:
                                finalboss.health = -1
                            print("Ruination Casted: All enemies eliminated")
                        if player.Spell == "Chance":
                            coin = Coin(player.rect.centerx-12, player.rect.centery-35)
                            coin_sprites.add(coin)
                            all_sprites.add(coin)
                            if random.randint(1,10) == 1:
                                for enemy in enemy_sprites:
                                    enemy.health -= 50
                                for sentry in sentry_sprites:
                                    sentry.health -= 30
                                for boss in boss_sprites:
                                    boss.health -= 100
                                for finalboss in finalboss_sprites:
                                    finalboss.health -= 100
                                print("Lucky! Damage to all enemies!")
                            else:
                                print("Better luck next time!")
                            coin_flip.play()
                        if player.Spell == "Buff":
                            player.buffed = True
                            player.buff_start = pygame.time.get_ticks()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_EQUALS:
                current_spell == "Ruination"
                player.Spell = "Ruination"
                print("Cheat Activated: Ruination Spell Equipped")
            if event.type == pygame.KEYDOWN and event.key == pygame.K_h:
                if potion_amount > 0 and player.health < player.max_health:
                    player.health = min(player.max_health, player.health + 50)
                    potion_amount -= 1
                    heal_noise.play()
                    print("used Potion, Health:", player.health)
                else:
                    print("No potions left or health is full.")
            if event.type == pygame.KEYDOWN and event.key == pygame.K_i:
                current_time = pygame.time.get_ticks()
                if current_time - last_inventory_toggle > 200:
                    print("Spellbook toggled")
                    show_inventory = not show_inventory
                    last_inventory_toggle = current_time
            if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                print(player.Spell)
# Item use keys (1–9) with cooldown
        current_time = pygame.time.get_ticks()
        for i in range(1, 10):
            if keys[getattr(pygame, f"K_{i}")] and current_time - player.last_item_use > 200:
                player.use_item(i-1)
                print("Item Used")
                player.last_item_use = current_time

# Draw everything
        screen.fill(White)
        floor_sprites.draw(screen)
        fog_sprites.draw(screen)
        all_sprites.draw(screen)
        projectiles.draw(screen)
        fireballs.draw(screen)
        explosions.draw(screen)
        icicles.draw(screen)
        enemy_sprites.draw(screen)
        pexplosions.draw(screen)
        evil_pexplosions.draw(screen)
        evil_icicles.draw(screen)

    pygame.quit()



Main()